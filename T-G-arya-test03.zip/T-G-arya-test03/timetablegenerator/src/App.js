import React from "react";
import { BrowserRouter as Router, Route, Routes, useLocation } from "react-router-dom";
import Navbar from "./components/Navbar";
import SignupPage from "./components/SignupPage";
import DocVerification from "./components/DocVerification";
import CertificateList from "./components/CertificateList";
import RejectedTransaction from "./components/RejectedTransaction";
import ApplicantsList from "./components/ApplicantsList";
import SelectedCertificate from "./components/SelectedCertificates";
import ReportGenerator from "./components/ReportGenerator";
import MeritList from "./components/MeritList";
import FeeStructure from "./components/FeeStructure";
import FeeReceipt from "./components/FeeReceipt";
import DocVerificationFEAdmission from "./components/DocVerificationFEAdmission";
import AdmissionFormView from "./components/AdmissionFormView";
import FeeReceiptFE from "./components/FeeReceiptFE";
import AdmissionFormViewFE from "./components/admissionFormViewFE";
import DocVerificationDSEAdmission from "./components/DocVerificationDSEAdmission";
import CancelAdmission from "./components/CancelAdmission";
import AdmissionFormViewDSE from "./components/admissionFormViewDSE";
function App() {
  const location = useLocation();
  const shouldShowNavbar = location.pathname !== "/";

  return (
    <>
      {shouldShowNavbar && <Navbar />}
      <Routes>
        <Route path="/" element={<SignupPage />} />
        <Route path="/documentverification" element={<DocVerification />} />
        <Route path="/transactionrejected" element={<RejectedTransaction />} />
        <Route path="/receitGeneration" element={<CertificateList />} />
        <Route path="/ApplicationList" element={<ApplicantsList />} />
        <Route path="/documentReceiptGenerator" element={<SelectedCertificate />} />
        <Route path="/selected" element={<SelectedCertificate />} />
        <Route path="/reportgeneration" element={<ReportGenerator />} />
        <Route path="/meritList" element={<MeritList />} />
        <Route path="/feeStructure" element={<FeeStructure />} />
        <Route path="/feeReceipt" element={<FeeReceipt />} />
        <Route path="/documentverificationFEAdmission" element={<DocVerificationFEAdmission />} />
        <Route path="/documentverificationDSEAdmission" element={<DocVerificationDSEAdmission />} />
        <Route path="/viewAdmissionForm" element={<AdmissionFormView />} />
        <Route path="/viewAdmissionFormFEandDSE" element={<AdmissionFormViewFE />} />
        <Route path="/viewAdmissionFormDSE" element={<AdmissionFormViewDSE/>} />
        <Route path="/feeReceiptFE" element={<FeeReceiptFE />} />
        <Route path="/CancelAdmission" element={<CancelAdmission />} />
      </Routes>
    </>
  );
}

export default function AppWrapper() {
  return (
    <Router>
      <App />
    </Router>
  );
}
