// Layout.js
import React from "react";
import { useLocation } from "react-router-dom";
import Navbar from "./Navbar";
import { Outlet } from "react-router-dom";

const Layout = () => {
  const location = useLocation();
  const showNavbar = location.pathname !== "/signup";

  return (
    <div>
      {showNavbar && <Navbar />}
      <Outlet /> {/* Render the matched child route */}
    </div>
  );
};

export default Layout;
