import React from 'react';
import './AdmissionFormView.css';
import DownloadPDFButton from './DownloadPDFButton';
import { useLocation } from "react-router-dom";
import { useNavigate } from "react-router-dom";

import { useRef,useState, useEffect } from "react";
import { useReactToPrint } from "react-to-print";

  


const AdmissionFormView = () => {
    

  const componentRef = useRef();
  const location = useLocation();
  const receivedState = location.state;
  const uidRecieved = receivedState.uidtoSend;
  console.log(uidRecieved);
  const [formData, setFormdata] = useState([]);

  const backUrl = 'http://localhost:3010/';

  // Replace backslashes with forward slashes
  function replaceBackslashWithSlash(inputString) {
    return inputString.replace(/\\/g, "/");
  }

  function replacePublic(inputString) {
    return inputString.replace("public", "");
  }


  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
  });
//   const dateOfBirth = formData.date_of_birth instanceof Date
//     ? formData.date_of_birth.toLocaleDateString()
//     : '';

    useEffect(() => {
      
            axios
                .get(`${backUrl}/getAdmissionForm/${uidRecieved}`)
                .then((response) => {
                    if (Array.isArray(response.data)) {
                        console.loh(response.data);
                        setFormdata(response.data);
                        console.log(formData);
                    } else {
                        console.error("Expected an array but got:", response.data);
                    }
                    // Set loading to false once data is fetched
                })
                .catch((error) => {
                    console.error("There was an error fetching the data!", error);
                    // Set loading to false even if there's an error
                });
        
    }, [uidRecieved]);


    const formatDate = (date) => {
      const d = new Date(date);
      const day = d.getDate();
      const month = d.getMonth() + 1; // Month is zero based, so we add 1
      const year = d.getFullYear();
      return `${day}/${month}/${year}`;
    };
    
    
    // Get current system date in dd-mm-yyyy format
    const currentDate = formatDate(new Date());
   
    
  
  

  return (
  <>
    { formData[0] === null && <p>loading...</p>}
    {formData[0] !== null &&
        
    <div id="pdf-content" ref={componentRef}>
    <form className="admission-form">
      <table className="form-table table1">
        <thead>
          {/* <tr>
            <th colSpan="4"> */}
              <div className="header">
                <img src="/gstlogo.png" alt="SIES Logo" className="logo" />
                <div className="header-left">
                  <div className="school-info">
                    <h2>SIES Graduate School of Technology</h2>
                    <p>Sri Chandrasekarendra Saraswati Vidyapuram Sector-V, Nerul, Navi Mumbai, Maharashtra 400706</p>
                    <p>Phone: 022 6108 2402</p>
                  </div>
                </div>
                <div className="header-right">
                  <img src={``} alt="Profile" className="profile-photo" />
                 
                  <tr></tr> 
                </div>
              </div>
            {/* </th>
          </tr> */}
          {/* <tr>
          <div className="header2-name">
                <td>  

                <p >{formData.personalDetails.fullName}</p><br />
                </td>
                <td>  

                <p>{currentDate}</p>
                </td>
          </div>
          </tr> */}
        </thead>
      </table>
      {/* <table>
        <tr>{formData.personalDetails.fullName}</tr>
        <tr>{currentDate}</tr>
        </table> */}
          
        <table className="form-table table2">
          <thead>
            <tr></tr>
            <tr>
            <th colSpan="4" className="title">
              <h3>ADMISSIONS (2023-24)</h3>
            </th>
          </tr>
          </thead>
          <tbody>
          <tr>
            <td className="label">Name</td>
            <td>{formData[0].fullname}</td>
            <td className="label">CET Application ID</td>
            <td>{formData[0].cet_application_id}</td>
          </tr>
          <tr>
            <td className="label">ID</td>
            <td>{formData[0].id}</td>
          </tr>
          <tr>
            <td className="label">Date of Birth</td>
            <td>{formData[0].date_of_birth}</td>
          </tr>
          <tr>
            <td className="label">Email Id</td>
            <td>{formData[0].email}</td>
          </tr>
          <tr>
            <td className="label">Mobile No.</td>
            <td>{formData[0].mobile_number}</td>
          </tr>
          <tr>
            <td className="label">Father's Name</td>
            <td>{formData[0].father_name}</td>
            <td className="label">Father's Occupation</td>
            <td>{formData[0].father_occupation}</td>
          </tr>
          <tr>
            <td className="label">Mobile No.</td>
            <td>{formData[0].father_mobile_number}</td>
          </tr>
          <tr>
            <td className="label">Mother's Name</td>
            <td>{formData[0].mother_name}</td>
            <td className="label">Mother's Occupation</td>
            <td>{formData[0].mother_occupation}</td>
          </tr>
          <tr>
            <td className="label">Mobile No.</td>
            <td>{formData[0].mother_mobile_number}</td>
          </tr>
          <tr>
            <td className="label">Annual Income</td>
            <td>{formData[0].annual_income}</td>
          </tr>
          <tr>
            <td className="label">Gender</td>
            <td>{formData[0].sex}</td>
          </tr>
          <tr>
            <td className="label">Correspondence Address</td>
            <td colSpan="3">{formData[0].corres_address}</td>
          </tr>
          <tr>
            <td className="label">State</td>
            <td colSpan="3">{formData[0].domicile}</td>
          </tr>
          <tr>
            <td className="label">Permanent Address</td>
            <td colSpan="3">{formData[0].permanent_address}</td>
          </tr>
          <tr>
            <td className="label">State</td>
            <td colSpan="3">{formData[0].domicile}</td>
          </tr>
          <tr>
            <td className="label">Area</td>
            <td>{formData[0].area}</td>
            <td className="label">Nationality</td>
            <td>{formData[0].nationality}</td>
          </tr>
          <tr>
            <td className="label">Religion</td>
            <td>{formData[0].religion}</td>
            <td className="label">Category</td>
            <td>{formData[0].category}</td>
          </tr>
          <tr>
            <td className="label">Domicile</td>
            <td>{formData[0].domicile}</td>
            <td className="label">Mother Tongue</td>
            <td>{formData[0].mother_tongue}</td>
          </tr>
          </tbody>
              
          </table>
          <table className="form-table table3">
          <tbody>
            <tr></tr>
          <tr className="sub-title">
            <td colSpan="4">JEE Details</td>
          </tr>
          <tr>
            <td className="label">JEE Application No</td>
            <td>{formData[0].jee_application_number}</td>
            <td className="label">JEE Percentile</td>
            <td>{formData[0].jee_percentile}</td>
          </tr>
          <tr className="sub-title">
            <td colSpan="4">CET Details</td>
          </tr>
          <tr>
            <td className="label">CET Roll No</td>
            <td>{formData[0].cet_roll_number}</td>
            <td className="label">CET Maths Percentage</td>
            <td>{formData[0].cet_maths_percentile}</td>
          </tr>
          <tr>
            <td className="label">CET Physics Percentage</td>
            <td>{formData[0].cet_physics_percentile}</td>
            <td className="label">CET Chemistry Percentage</td>
            <td>{formData[0].cet_chemistry_percentile}</td>
          </tr>
          <tr>
            <td className="label">CET Percentile</td>
            <td>{formData[0].cet_percentile}</td>
          </tr>
          <tr className="sub-title">
            <td colSpan="4">HSC Details</td>
          </tr>
          <tr>
            <td className="label">HSC Maths Marks</td>
            <td>{formData[0].hsc_maths}</td>
            <td className="label">HSC Physics Marks</td>
            <td>{formData[0].hsc_physics}</td>
          </tr>
          <tr>
            <td className="label">HSC Chemistry Marks</td>
            <td>{formData[0].hsc_chemistry}</td>
            <td className="label">HSC PCM Percentage</td>
            <td>{formData[0].hsc_pcm_percentage}</td>
          </tr>
          <tr>
            <td className="label">HSC Vocational Subject Name</td>
            <td>{formData[0].hsc_vocational_subject_name}</td>
            <td className="label">HSC Vocational Subject Marks</td>
            <td>{formData[0].hsc_vocational_subject_percentage}</td>
          </tr>
          <tr>
            <td className="label">HSC PMV Percentage</td>
            <td>{formData[0].hsc_vocational_subject_percentage}</td>
          </tr>
          <tr>
            <td className="label">Academic Qualification</td>
            <td colSpan="3">
              <table className="inner-table">
                <tbody>
                  <tr></tr>
                  <tr>
                    <td>Exam Passed</td>
                    <td>Name of Board/University</td>
                    <td>Year of Passing</td>
                    <td>Total Marks</td>
                    <td>Marks Obtained</td>
                    <td>% of Marks</td>
                  </tr>
                  {/* <tr>
                    <td>S.S.C(10th)</td>
                    <td>{formData.sscBoard}</td>
                    <td>{formData.sscyearofPass}</td>
                    <td>{formData.ssctotalMarks} </td>
                    <td>{formData.sscmarksObtained}</td>
                    <td>{formData.sscPercentage}</td>
                  </tr>
                  <tr>
                    <td>H.S.C(12th) / Diploma</td>
                    <td>{formData.hscBoard}</td>
                    <td>{formData.hscyearofPass}</td>
                    <td>{formData.hsctotalMarks}</td>
                    <td>{formData.hscmarksObtained}</td>
                    <td>{formData.hscPercentage}</td>
                  </tr> */}
                </tbody>
              </table>
            </td>
          </tr>
          </tbody>
          </table>
          <table className="form-table">
          <tbody>
          <tr>
            <td className="label">Branch Preference</td>
            <td colSpan="3">
              <table className="inner-table">
                <tbody>
                  <tr></tr>
                  <tr>
                    <td>1 Preference</td>
                    <td>{formData[0].preferences[0]}</td>
                    <td>2 Preference</td>
                    <td>{formData[0].preferences[1]}</td>
                  </tr>
                  <tr>
                    <td>3 Preference</td>
                    <td>{formData[0].preferences[2]}</td>
                    <td>4 Preference</td>
                    <td>{formData[0].preferences[3]}</td>
                  </tr>
                  <tr>
                    <td>5 Preference</td>
                    <td>{formData[0].preferences[4]}</td>
                    <td>6 Preference</td>
                    <td>{formData[0].preferences[5]}</td>
                    </tr>
                  <tr>
                    <td>7 Preference</td>
                    <td>{formData[0].preferences[6]}</td>
                    <td>8 Preference</td>
                    <td>{formData[0].preferences[7]}</td>
                  </tr>
                </tbody>
              </table>
            </td>
          </tr>
          </tbody>
          </table>
          <table className="form-table">
          <tbody>
            <tr></tr>
          <tr>
              <td className="label">Signature</td>
              <td colSpan="3">
                <img src={`https://linear-factor-simply-wagon.trycloudflare.com/files/${replaceBackslashWithSlash(replacePublic(formData[0].signature))}`} alt="Signature" className="signature-img" />
              </td>
            </tr>
            <tr></tr>
            </tbody>
          </table>
          <table className="form-table">
          <tbody>
            <tr></tr>
          <tr>
            <td className="label">Transaction Details</td>
            <td colSpan="3">
              <table className="inner-table">
                <tbody>
                  <tr>
                    <td>Payment Type</td>
                    <td>{formData[0].transactionmode}</td>
                    <td>Amount</td>
                    <td>{formData[0].transaction_amount}</td>
                  </tr>
                  <tr>
                    {/* <td>Bank Name</td>
                    <td>{data.bankName}</td> */}
                    <td>Transaction ID</td>
                    <td>{formData[0].transaction_id}</td>
                  </tr>
                  <tr>
                    <td>Transaction Date</td>
                    <td>{formData[0].transaction_date}</td>
                    <td>Payment For</td>
                    <td>{formData[0].transaction_against}</td>
                  </tr>
                </tbody>
              </table>
            </td>
          </tr>
          {/* <tr>
            <td className="label">Other Details</td>
            <td colSpan="3">{data.otherDetails}</td>
          </tr> */}
        </tbody>
      </table>
    </form>
    {/* <DownloadPDFButton /> */}
    <div className="buttons">
      <button onClick={handlePrint}>Download PDF copy of form</button>
      <p>(Please download the print before submitting the form)</p>
    </div>
  </div>
    }
  </>
    
  );
};

export default AdmissionFormView;