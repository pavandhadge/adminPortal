import { useRef, useEffect, useState } from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle";
import { useReactToPrint } from 'react-to-print';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import './FeeReceipt.css'; // Assuming you have a CSS file for additional styling
import { useNavigate, useLocation } from 'react-router-dom';

function FeeReceipt() {
  const currentDate = new Date();
  const navigate = useNavigate();
  const location = useLocation();
  const receivedState = location.state;
  const [customDate, setCustomDate] = useState('');
  
  // Function to format date
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day} ${month} ${year}`;
  };

  const [formData, setFormData] = useState({
    rollNo: '222a3065',
    studentName: 'Arshad',
    receiptDate: formatDate(new Date()), // Initialize with current date
  });

  // Update formattedDate when customDate changes
  useEffect(() => {
    if (customDate) {
      setFormData((prev) => ({
        ...prev,
        receiptDate: formatDate(customDate),
      }));
    } else {
      setFormData((prev) => ({
        ...prev,
        receiptDate: formatDate(new Date()), // Reset to current date if no custom date
      }));
    }
  }, [customDate]);

  const componentRef = useRef();

  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
    documentTitle: 'FeeReceipt',
    pageStyle: `
      @page {
        size: auto;
      }
      @media print {
        body {
          -webkit-print-color-adjust: exact;
        }
        .dateignore {
          display: none !important;
        }
      }
    `
  });

  const sendFeeReceipt = async () => {
    alert('Sending fee receipt...');
    const canvas = await html2canvas(componentRef.current);
    const imgData = canvas.toDataURL('image/png');

    const pdf = new jsPDF();
    const margin = 10;
    const pdfWidth = pdf.internal.pageSize.getWidth() - margin * 2;
    const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
    pdf.addImage(imgData, 'PNG', margin, margin, pdfWidth, pdfHeight);
    const pdfBlob = pdf.output('blob');

    const formDataToSend = new FormData();
    formDataToSend.append('email', receivedState.email);
    formDataToSend.append('file', pdfBlob, 'FeeReceipt.pdf');

    try {
      const response = await fetch(`${process.env.REACT_APP_backUrl}/uploadfeereceipt`, {
        method: 'POST',
        body: formDataToSend,
      });

      if (!response.ok) {
        throw new Error('Network response was not ok');
      }

      const result = await response.json();
      
      console.log(result);
      alert('Fee receipt sent successfully!');
    } catch (error) {
      console.error('There was an error sending the PDF!', error);
    }
  };

  const handleDownload = async () => {
    alert('Downloading fee receipt...');
    const canvas = await html2canvas(componentRef.current);
    const imgData = canvas.toDataURL('image/png');

    const pdf = new jsPDF();
    const margin = 10;
    const pdfWidth = pdf.internal.pageSize.getWidth() - margin * 2;
    const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
    pdf.addImage(imgData, 'PNG', margin, margin, pdfWidth, pdfHeight);
    pdf.save('FeeReceipt.pdf');
  };

  return (
    <div>
      <div className="row">
        <div className="col">
          <button type="button" className="btn backbtn" onClick={() => { navigate('/ApplicationList') }}>Back</button>
        </div>
      </div>
      <div className="col colpay dateignore" >
            <input 
              type="date" 
              onChange={(e) => setCustomDate(e.target.value)}
              placeholder="Select Custom Date" 
              style={{ display: 'block' }}
            />
          </div>
      <div ref={componentRef} style={{ padding: '20px', margin: '20px' }}>
        <div className="header">
          <img src="/gstlogo.png" alt="SIES Logo" className="logo" />
          <div className="info">
            <h1>The South Indian Education Society</h1>
            <p>SIES Graduate School of Technology</p>
            <p>Sri Chandrasekarendra Saraswati Vidyapuram Sector-V, Nerul, Navi Mumbai, Maharashtra 400706</p>
            <p>Fee Receipt (Student Copy - Original)</p>
          </div>
        </div>
        <div className="body">
          <div className="row rowpay2">
            <div className="col colpay2">
              Admission form fees
            </div>
          </div>
          <div className="row rowpay">
            <div className="col colpay">
              User ID : {receivedState.uidtoSend}
            </div>
            <div className="col colpay">
              Student Name : {receivedState.fullName}
            </div>
          </div>
          
          
          <div className="row rowpay">
            <div className="col colpay">
              Receipt Date : {formData.receiptDate}
            </div>
            <div className="col colpay">
              Amount Paid : 2500
            </div>
          </div>
          <br />
          <br />
          <br />
          <div className="row rowpay">
            <div className="col colpay">
              <div className="signature">
                <p>Signature</p>
                <p>(Account by : Vijayalakshami )</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="row row-send">
        <div className="col col-send">
          <button type="button" className="btn btn-send" onClick={sendFeeReceipt}>
            Send PDF
          </button>
        </div>
        <div className="col col-send">
          <button type="button" className="btn btn-send" onClick={handleDownload}>
            Download
          </button>
        </div>
      </div>
    </div>
  );
}

export default FeeReceipt;
