import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './SignupPage.css';
import axios from 'axios';

const back_url = process.env.REACT_APP_backUrl;

export default function SignupPage({ onSignupComplete }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate(); // Hook for navigation

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      // Sending GET request to the backend
      const response = await axios.get(`${back_url}/login?email=${email}&password=${password}`);

      const result =  response.data;
      console.log(result.name);
      const adminName = result.name;
      console.log(typeof(result.name));
      const data = {nameReceived : result.name};
      // console.log(response.json());
      if (result.message !== "Invalid email or password") {
        navigate('/ApplicationList',{state :  {adminName} }); // Replace with your desired route
      } else {
        // Handle errors
        console.error('Login failed:', result.message);
        alert('Login failed')
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <>
      <br /><br /><br /><br /><br /><br /><br /><br />
      <h3>Admin portal Login  </h3>
      <form className='formedit' onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="exampleInputEmail1" className="form-label">
            Email address
          </label>
          <input
            type="email"
            className="form-control"
            id="exampleInputEmail1"
            aria-describedby="emailHelp"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <div id="emailHelp" className="form-text">
            We'll never share your email with anyone else.
          </div>
        </div>
        <div className="mb-3">
          <label htmlFor="exampleInputPassword1" className="form-label">
            Password
          </label>
          <input
            type="password"
            className="form-control"
            id="exampleInputPassword1"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        <button type="submit" className="btn btn-primary">
          Login
        </button>
      </form>
    </>
  );
}
