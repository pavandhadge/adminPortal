import React from "react";
import {useRef, useState, useEffect} from "react";
import { useLocation } from "react-router-dom";
import './AdmissionFormView.css';
import { useNavigate } from "react-router-dom";
import { useReactToPrint } from "react-to-print";
import axios from "axios";

function AdmissionFormView(){
    const backUrl = process.env.REACT_APP_backUrl;

    const componentRef = useRef();
    const location = useLocation();
    const receivedState = location.state;
    const uidRecieved = receivedState.uidtoSend;
    console.log(uidRecieved);
    const [editingNameState, setEditingNameState] = useState(false);
    const [inputValue, setInputValue] = useState('');
    const [formData, setFormdata] = useState([]);
    const navigate = useNavigate();
    useEffect(() => {
      
        axios
            .get(`${backUrl}/getAdmissionForm/${uidRecieved}`)
            .then((response) => {
                if (Array.isArray(response.data)) {
                    console.log(response.data);
                    setFormdata(response.data);
                    console.log('Formdata Recieved : ',formData);
                } else {
                    console.error("Expected an array but got:", response.data);
                }
                // Set loading to false once data is fetched
            })
            .catch((error) => {
                console.error("There was an error fetching the data!", error);
                // Set loading to false even if there's an error
            });
    
}, [uidRecieved]);
const formatDate = (date) => {
    const d = new Date(date);
    const day = d.getDate();
    const month = d.getMonth() + 1; // Month is zero based, so we add 1
    const year = d.getFullYear();
    return `${day}/${month}/${year}`;
  };
  

  const updateDictionary = (id, key, newValue) => {
    setFormdata((prevData) =>
      prevData.map((item) =>
        item.id === id ? { ...item, [key]: newValue } : item
      )
    );
  };
  const handleNameChange = (event)=>{
    setInputValue(event.target.value);
    console.log(inputValue);
    updateDictionary(formData[0].id, 'fullname', inputValue);
  }



  const navigateToDocVerification = (uid) => {
    const data = { uidRecieved : uid };
    console.log(data);
    navigate('/documentverification', { state: data });
  };

  // Replace backslashes with forward slashes
  // function replaceBackslashWithSlash(inputString) {
  //   return inputString.replace(/\\/g, "/");
  // }
  function replaceBackslashWithSlash(inputString) {
    // Check if inputString is a valid string
    if (typeof inputString === 'string') {
      return inputString.replace(/\\/g, "/");
    }
    // Return inputString as-is if it is not a valid string
    return inputString;
  }

  // function replacePublic(inputString) {
  //   return inputString.replace("public", "");
  // }
  function replacePublic(inputString) {
    // Ensure inputString is a string and not null or undefined
    if (typeof inputString === 'string') {
      return inputString.replace("public", "");
    }
    // Return inputString as-is if it is null, undefined, or not a string
    return inputString;
  }

  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
  });
  // Get current system date in dd-mm-yyyy format
  const currentDate = formatDate(new Date());
  
//   console.log(`http://localhost:3010/files/${replaceBackslashWithSlash(replacePublic(formData[0].photo))}`)

return (
  <>
    {/* <div className="title">
        <div className="row">
          <div className="col-1">
            <button
              type="button"
              onClick={navigateToDocVerification}
              className="btn backbtn"
            >
              Back
            </button>
          </div>
          <div className="col-11 titlepage">
            <h2>Documents and Transaction Approval</h2>
          </div>
        </div>
      </div> */}
    {formData.map((data) => (
      <>
        <div id="pdf-content">
          <form className="admission-form" ref={componentRef}>
            <table className="form-table table1">
              <thead>
                {/* <tr>
            <th colSpan="4"> */}

                <div className="header">
                  <img src="/gstlogo.png" alt="SIES Logo" className="logo" />
                  <div className="header-left">
                    <div className="school-info">
                      <h2>SIES Graduate School of Technology</h2>
                      <p>
                        Sri Chandrasekarendra Saraswati Vidyapuram Sector-V,
                        Nerul, Navi Mumbai, Maharashtra 400706
                      </p>
                      <p>Phone: 022 6108 2402</p>
                    </div>
                  </div>
                  <div className="header-right">
                    <img
                      src={`${process.env.REACT_APP_backUrl}/files/${replaceBackslashWithSlash(
                        replacePublic(data.photo)
                      )}`}
                      alt="Profile"
                      className="profile-photo"
                    />

                    <tr></tr>
                  </div>
                </div>

                {/* 
              <div className="header">
                <img src="/gstlogo.png" alt="SIES Logo" className="logo" />
                <div className="header-left">
                  <div className="school-info">
                    <h2>SIES Graduate School of Technology</h2>
                    <p>Sri Chandrasekarendra Saraswati Vidyapuram Sector-V, Nerul, Navi Mumbai, Maharashtra 400706</p>
                    <p>Phone: 022 6108 2402</p>
                  </div>
                </div>
                <div className="header-right">
                  <img src={`http://localhost:3010/files/${replaceBackslashWithSlash(replacePublic(data.photo))}`} alt="Profile" className="profile-photo" />
                 
                  <tr>{currentDate}</tr> 
                </div>
              </div> */}
                {/* </th>
          </tr> */}
                {/* <tr>
          <div className="header2-name">
                <td>  

                <p >{formData.personalDetails.fullName}</p><br />
                </td>
                <td>  

                <p>{currentDate}</p>
                </td>
          </div>
          </tr> */}
              </thead>
            </table>
            {/* <table>
        <tr>{formData.personalDetails.fullName}</tr>
        <tr>{currentDate}</tr>
        </table> */}

            <table className="form-table table2">
              <thead>
                <tr></tr>
                <tr>
                  <th colSpan="4" className="title">
                    <h3>ADMISSIONS (2024-25)</h3>
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="label">Name</td>
                  <td onClick={()=>{setEditingNameState(true)}} onBlur={()=>{setEditingNameState(false)}} >
                    {editingNameState === true && (
                      <input
                        class="form-control"
                        type="text"
                        placeholder={data.fullname}
                        value={data.fullname}
                        aria-label="default input example"
                        onChange={handleNameChange}
                      ></input>
                    )}
                    {editingNameState === false && data.fullname}
                  </td>
                  <td className="label">CET Application ID</td>
                  <td>{data.cet_application_id}</td>
                </tr>
                <tr>
                  <td className="label">ID</td>
                  <td>{data.id}</td>
                </tr>
                <tr>
                  <td className="label">Date of Birth</td>
                  <td>{data.date_of_birth}</td>
                </tr>
                <tr>
                  <td className="label">Email Id</td>
                  <td>{data.email}</td>
                </tr>
                <tr>
                  <td className="label">Mobile No.</td>
                  <td>{data.mobile_number}</td>
                </tr>
                <tr>
                  <td className="label">Father's Name</td>
                  <td>{data.father_name}</td>
                  <td className="label">Father's Occupation</td>
                  <td>{data.father_occupation}</td>
                </tr>
                <tr>
                  <td className="label">Mobile No.</td>
                  <td>{data.father_mobile_number}</td>
                </tr>
                <tr>
                  <td className="label">Mother's Name</td>
                  <td>{data.mother_name}</td>
                  <td className="label">Mother's Occupation</td>
                  <td>{data.mother_occupation}</td>
                </tr>
                <tr>
                  <td className="label">Mobile No.</td>
                  <td>{data.mother_mobile_number}</td>
                </tr>
                <tr>
                  <td className="label">Annual Income</td>
                  <td>{data.annual_income}</td>
                </tr>
                <tr>
                  <td className="label">Gender</td>
                  <td>{data.sex}</td>
                </tr>
                <tr>
                  <td className="label">Correspondence Address</td>
                  <td colSpan="3">{data.corres_address}</td>
                </tr>
                <tr>
                  <td className="label">State</td>
                  <td colSpan="3">{data.domicile}</td>
                </tr>
                <tr>
                  <td className="label">Permanent Address</td>
                  <td colSpan="3">{data.permanent_address}</td>
                </tr>
                <tr>
                  <td className="label">State</td>
                  <td colSpan="3">{data.domicile}</td>
                </tr>
                <tr>
                  <td className="label">Area</td>
                  <td>{data.area}</td>
                  <td className="label">Nationality</td>
                  <td>{data.nationality}</td>
                </tr>
                <tr>
                  <td className="label">Religion</td>
                  <td>{data.religion}</td>
                  <td className="label">Category</td>
                  <td>{data.category}</td>
                </tr>
                <tr>
                  <td className="label">Domicile</td>
                  <td>{data.domicile}</td>
                  <td className="label">Mother Tongue</td>
                  <td>{data.mother_tongue}</td>
                </tr>
              </tbody>
            </table>
            <table className="form-table table3">
              <tbody>
                <tr></tr>
                <tr className="sub-title">
                  <td colSpan="4">JEE Details</td>
                </tr>
                <tr>
                  <td className="label">JEE Application No</td>
                  <td>{data.jee_application_number}</td>
                  <td className="label">JEE Percentile</td>
                  <td>{data.jee_percentile}</td>
                </tr>
                <tr className="sub-title">
                  <td colSpan="4">CET Details</td>
                </tr>
                <tr>
                  <td className="label">CET Roll No</td>
                  <td>{data.cet_roll_number}</td>
                  <td className="label">CET Maths Percentage</td>
                  <td>{data.cet_maths_percentile}</td>
                </tr>
                <tr>
                  <td className="label">CET Physics Percentage</td>
                  <td>{data.cet_physics_percentile}</td>
                  <td className="label">CET Chemistry Percentage</td>
                  <td>{data.cet_chemistry_percentile}</td>
                </tr>
                <tr>
                  <td className="label">CET Percentile</td>
                  <td>{data.cet_percentile}</td>
                </tr>
                <tr className="sub-title">
                  <td colSpan="4">HSC Details</td>
                </tr>
                <tr>
                  <td className="label">HSC Maths Marks</td>
                  <td>{data.hsc_maths}</td>
                  <td className="label">HSC Physics Marks</td>
                  <td>{data.hsc_physics}</td>
                </tr>
                <tr>
                  <td className="label">HSC Chemistry Marks</td>
                  <td>{data.hsc_chemistry}</td>
                  <td className="label">HSC PCM Percentage</td>
                  <td>{data.hsc_pcm_percentage}</td>
                </tr>
                <tr>
                  <td className="label">HSC Vocational Subject Name</td>
                  <td>{data.hsc_vocational_subject_name}</td>
                  <td className="label">HSC Vocational Subject Marks</td>
                  <td>{data.hsc_vocational_subject_percentage}</td>
                </tr>
                <tr>
                  <td className="label">HSC PMV Percentage</td>
                  <td>{data.hsc_vocational_subject_percentage}</td>
                </tr>
                <tr>
                  <td className="label">Academic Qualification</td>
                  <td colSpan="3">
                    <table className="inner-table">
                      <tbody>
                        <tr></tr>
                        <tr>
                          <td>Exam Passed</td>
                          <td>Name of Board/University</td>
                          <td>Year of Passing</td>
                          <td>Total Marks</td>
                          <td>Marks Obtained</td>
                          <td>% of Marks</td>
                        </tr>
                        <tr>
                          <td>S.S.C(10th)</td>
                          <td>{data["10th_board_name"]}</td>
                          <td>{data["10th_year_of_passing"]}</td>
                          <td>{data["10th_total_marks"]} </td>
                          <td>{data["10th_marks_obtained"]}</td>
                          <td>{data["10th_percentage"]}</td>
                        </tr>
                        <tr>
                          <td>H.S.C(12th) / Diploma</td>
                          <td>{data["12th_board_name"]}</td>
                          <td>{data["12th_year_of_passing"]}</td>
                          <td>{data["12th_total_marks"]}</td>
                          <td>{data["12th_marks_obtained"]}</td>
                          <td>{data["12th_percentage"]}</td>
                        </tr>
                      </tbody>
                    </table>
                  </td>
                </tr>
              </tbody>
            </table>
            <table className="form-table">
              <tbody>
                <tr>
                  <td className="label">Branch Preference</td>
                  <td colSpan="3">
                    <table className="inner-table">
                      <tbody>
                        <tr></tr>
                        <tr>
                          <td>1 Preference</td>
                          <td>{data.preferences[0]}</td>
                          <td>2 Preference</td>
                          <td>{data.preferences[1]}</td>
                        </tr>
                        <tr>
                          <td>3 Preference</td>
                          <td>{data.preferences[2]}</td>
                          <td>4 Preference</td>
                          <td>{data.preferences[3]}</td>
                        </tr>
                        <tr>
                          <td>5 Preference</td>
                          <td>{data.preferences[4]}</td>
                          <td>6 Preference</td>
                          <td>{data.preferences[5]}</td>
                        </tr>
                        <tr>
                          <td>7 Preference</td>
                          <td>{data.preferences[6]}</td>
                          <td>8 Preference</td>
                          <td>{data.preferences[7]}</td>
                        </tr>
                      </tbody>
                    </table>
                  </td>
                </tr>
              </tbody>
            </table>
            <table className="form-table">
              <tbody>
                <tr></tr>
                <tr>
                  <td className="label">Signature</td>
                  <td colSpan="3">
                    <img
                      src={`${process.env.REACT_APP_backUrl}/files/${replaceBackslashWithSlash(
                        replacePublic(data.signature)
                      )}`}
                      alt="Signature"
                      className="signature-img"
                    />
                  </td>
                </tr>
                <tr></tr>
              </tbody>
            </table>
            <table className="form-table">
              <tbody>
                <tr></tr>
                <tr>
                  <td className="label">Transaction Details</td>
                  <td colSpan="3">
                    <table className="inner-table">
                      <tbody>
                        <tr>
                          <td>Payment Type</td>
                          <td>{data.transactionmode}</td>
                          <td>Amount</td>
                          <td>{data.transaction_amount}</td>
                        </tr>
                        <tr>
                          {/* <td>Bank Name</td>
                    <td>{data.bankName}</td> */}
                          <td>Transaction ID</td>
                          <td>{data.transaction_id}</td>
                        </tr>
                        <tr>
                          <td>Transaction Date</td>
                          <td>{data.transaction_date}</td>
                          <td>Payment For</td>
                          <td>{data.transaction_against}</td>
                        </tr>
                      </tbody>
                    </table>
                  </td>
                </tr>
                {/* <tr>
            <td className="label">Other Details</td>
            <td colSpan="3">{data.otherDetails}</td>
          </tr> */}
              </tbody>
            </table>
          </form>
          {/* <DownloadPDFButton /> */}
          <div className="buttons">
            <button onClick={handlePrint}>Download PDF copy of form</button>
            <p>(Please download the print before submitting the form)</p>
          </div>
        </div>
      </>
    ))}
  </>
);

}



export default AdmissionFormView;