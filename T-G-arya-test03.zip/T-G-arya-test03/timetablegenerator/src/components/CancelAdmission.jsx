import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle"; //bootstrap.bundle.min.js / bootstrap.bundle.js
import "./ApplicantsList.css";
import React, { useState , useEffect } from "react";
import { json, useLocation, useNavigate } from "react-router-dom";
import axios from 'axios';
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";



function CancelAdmission() {
  const [examType, setExamType] = useState('cet'); // Default is 'cet'

  const backURL  = process.env.REACT_APP_backUrl;

  const [AdmissionType, setAdmissionType] = useState("FE Admission CAP");
  const AdmissionTypeBrochureInstituteLevel = () => {
    setAdmissionType("Brochure Institute Level");
  };
  const AdmissionTypeFEAdmissionInstitute = () => {
    setAdmissionType("FE Admission Institute level");
  };
  const BrochureTypeAgainstCAP = () => {
    setAdmissionType("Brochure Against CAP");
  };
  const AdmissionTypeFEMinority = () => {
    setAdmissionType("FE Admission Minority");
  };
  const AdmissionTypeFECAP = () => {
    setAdmissionType("FE Admission CAP");
  };
  const AdmissionTypeFEAgainstCAPVacancy = () => {
    setAdmissionType("FE Admission against CAP Vacancy");
  };
  const AdmissionTypeFETFWS = () => {
    setAdmissionType("FE Admission TFWS");
  };
  const AdmissionTypeDSECAP = () => {
    setAdmissionType("DSE CAP");
    setClassSE();
  };
  const AdmissionTypeDSEAgainstCAPVacancy = () => {
    setAdmissionType("DSE Against CAP Vacancy");
    setClassSE();
  };
  const AdmissionTypeDSEMinority = () => {
    setAdmissionType("DSE Minority");
    setClassSE();
  };


  const [Class, setClass] = useState("FE");
  const setClassFE = ()=>{
    setClass("FE");
  };
  const setClassSE = ()=>{
    setClass("SE");
  };
  const setClassTE = ()=>{
    setClass("TE");
  };
  const setClassBE = ()=>{
    setClass("BE");
  };



  const [AdmissionStatus, setAdmissionStatus] = useState("Admitted");

  const setAdmissionStatusAdmitted = ()=>{
    setAdmissionStatus("Admitted");
  }

  const setAdmissionStatusCancelled = ()=>{
    setAdmissionStatus("Cancelled");
  }

  const [DocStatus, setDocStatus] = useState("Not Approved");
  const setDocStatusApproved = ()=>{
    setDocStatus("Approved");
  };
  const setDocStatusNotApproved = ()=>{
    setDocStatus("Not Approved");
  };
  const setDocStatusRejected = ()=>{
    setDocStatus("Rejected");
  };

  const [TransactionStatus, setTransactionStatus] = useState("Not Approved");
  const setTransactionStatusApproved = ()=>{
    setTransactionStatus("Approved");
  }
  const setTransactionStatusNotApproved = ()=>{
    setTransactionStatus("Not Approved");
  }
  const setTransactionStatusRejected= ()=>{
    setTransactionStatus("Rejected");
  }
 const setTransactionStatusNotApplicable=()=>{
  setTransactionStatus("Not Applicable");
 }

////Used for displaying content in table
  const [data2, setData] = useState([]);

  useEffect(()=>{
    const a=10;

    localStorage.setItem("state",JSON.stringify(DocStatus));
  },[setDocStatus])
  useEffect(()=>{
    const retrived = JSON.parse(localStorage.getItem("state"))
    console.log(retrived)
    if(retrived === 'Not Appproved'){
      setDocStatusNotApproved();
    }
    else if(retrived === 'Appproved'){
      setDocStatusApproved();
    }
    else if(retrived === 'Rejected'){
      setDocStatusRejected();
    }
  },[])
  const fetchData = async () => {
    ///Admission form for institute level students
    if(AdmissionType === 'FE Admission Institute level' && Class === 'FE'){
      try {
        const response = await axios.get(`${backURL}/FEadmissiondataInstituteLevel`, {
          params: {
            class: Class,
            admissionType: AdmissionType
          }
        });
        setData(response.data);
      } catch (error) {
        console.error('There was an error fetching the data!', error);
      }
    }
    ///Admission form for students of SE TE BE
    else if(AdmissionType === 'Admission' && Class !== 'FE'){
      try {
        const response = await axios.get(`${backURL}/higheradmissiondata`, {
          params: {
            class: Class,
            admissionType: AdmissionType
          }
        });
        setData(response.data);
      } catch (error) {
        console.error('There was an error fetching the data!', error);
      }
    }
    ///Applicants list of brochure institute level
    else if(AdmissionType === 'Brochure Institute Level'){
      try {
        const response = await axios.get(`${backURL}/brochuredata`, {
          params: {
            class: Class,
            // admissionType: AdmissionType
          }
        });
        setData(response.data);
      } catch (error) {
        console.error('There was an error fetching the data!', error);
      }
    }
    ///Applicants list of CAP vacancy
    else if(AdmissionType === 'Brochure Against CAP'){
      try {
        const response = await axios.get(`${backURL}/brochuredataAgainstCAP`, {
          params: {
            class: Class,
            // admissionType: AdmissionType
          }
        });
        setData(response.data);
      } catch (error) {
        console.error('There was an error fetching the data!', error);
      }
    }
    ///Minority admission students
    else if(AdmissionType === 'FE Admission Minority'){
      try {
        const response = await axios.get(`${backURL}/admissiondataMinority`, {
          params: {
            class: Class,
            // admissionType: AdmissionType
          }
        });
        setData(response.data);
      } catch (error) {
        console.error('There was an error fetching the data!', error);
      }
    }
    else if(AdmissionType === 'FE Admission against CAP Vacancy'){
      try {
        const response = await axios.get(`${backURL}/FEadmissionAgainstCAPvacancy`, {
          params: {
            class: Class,
            // admissionType: AdmissionType
          }
        });
        setData(response.data);
      } catch (error) {
        console.error('There was an error fetching the data!', error);
      }
    }
    else if(AdmissionType === 'FE Admission CAP'){
      try {
        const response = await axios.get(`${backURL}/FEadmissionCAP`, {
          params: {
            class: Class,
            // admissionType: AdmissionType
          }
        });
        setData(response.data);
      } catch (error) {
        console.error('There was an error fetching the data!', error);
      }
    }
    else if(AdmissionType === 'FE Admission TFWS'){
      try {
        const response = await axios.get(`${backURL}/admissiondataFETFWS`, {
          params: {
            class: Class,
            // admissionType: AdmissionType
          }
        });
        setData(response.data);
      } catch (error) {
        console.error('There was an error fetching the data!', error);
      }
    }
    else if(AdmissionType === 'DSE CAP'){
      try {
        const response = await axios.get(`${backURL}/admissiondataDSECAP`, {
          params: {
            class: Class,
            // admissionType: AdmissionType
          }
        });
        setData(response.data);
        console.log(data2)
      } catch (error) {
        console.error('There was an error fetching the data!', error);
      }
    }
    else if(AdmissionType === 'DSE Against CAP Vacancy'){
      try {
        const response = await axios.get(`${backURL}/admissiondataDSEAgainstCAPVacancy`, {
          params: {
            class: Class,
            // admissionType: AdmissionType
          }
        });
        setData(response.data);
      } catch (error) {
        console.error('There was an error fetching the data!', error);
      }
    }
    else if(AdmissionType === 'DSE Minority'){
      try {
        const response = await axios.get(`${backURL}/admissiondataDSEMinority`, {
          params: {
            class: Class,
            // admissionType: AdmissionType
          }
        });
        setData(response.data);
      } catch (error) {
        console.error('There was an error fetching the data!', error);
      }
    }
    
    
  };

  useEffect(() => {
    fetchData();
  }, [Class, AdmissionType, data2]);

//   useEffect(() => {
//     // This useEffect will run whenever `data2` changes.
//     console.log(data2); // Logs the updated state.
//   }, [data2]);

  // useEffect(() => {
  //   // This useEffect will run whenever `data2` changes.
  //   console.log(data2); // Logs the updated state.
  // }, [data2]); 
  const location = useLocation();
  // const name = location.state?.name || "No name received";
  const nameRecieved = location.state?.adminName || "None";
  console.log("Received from login page : ",nameRecieved);
  const navigate = useNavigate();
  const navigateToDocVerification = (uid) => {
    const data = { uidRecieved : uid };
    console.log(data);
    navigate('/documentverification', { state: data });
  };

  let indexingtable = 1;
  ///Navigate for docverifcation FE admission
  const navigateToDocVerificationFEAdmission = (uid) => {
    const data = { uidRecieved : uid , nameRecieved};
    console.log(data);
    navigate('/documentverificationFEAdmission', { state: data });
  };


  function updateStatus(dataArray, targetId, newDocumentStatus, newTransactionStatus) {
    // Iterate through each object in the array
    for (let i = 0; i < dataArray.length; i++) {
        // Check if the current object's id matches the targetId
        if (dataArray[i].id === targetId) {
            // Update the documentsApproved and transactionproofStatus fields
            dataArray[i].documentsApproved = newDocumentStatus;
            dataArray[i].transactionproofStatus = newTransactionStatus;
            break; // Exit the loop once the target object is updated
        }
    }
    return dataArray;
}


  const handleAdmissionCancel = async (uid)=>{
    const uidToCancelAdmission = uid;
    try{
        const response = await axios.put(`${backURL}/AdmissionCancel/${uidToCancelAdmission}`);
        console.log("Response : ",response);
        
        data2 = updateStatus(data2, uidToCancelAdmission,"Cancelled","Canceled");

    }catch(error){
        console.log("Error while canceeling : ",error);
    }
    
  }

  const handleAdmissionRetake = async (uid)=>{
    const uidToCancelAdmission = uid;
    try{
        const response = await axios.put(`${backURL}/AdmissionRetake/${uidToCancelAdmission}`);
        console.log("Response : ",response);
        
        data2 = updateStatus(data2, uidToCancelAdmission,"Approved","Approved");

    }catch(error){
        console.log("Error while canceeling : ",error);
    }
    
  }

  const navigateToDocVerificationDSEAdmission = (uid) => {
    const data = { uidRecieved : uid , nameRecieved};
    console.log(data);
    navigate('/documentverificationDSEAdmission', { state: data });
  };
  // const docVerificationPage = (name, applicationNumber) =>
  //   navigate("/documentverification ", { state: { name, applicationNumber } });

  //generating excel
  const generateExcelBrochureInstituteLevel = async () => {
    // console.log("Excel triggered : ",);
    try {
      const response = await axios.get(`${backURL}/getBrochureInstituteLevel`);
      console.log('Brochure excel received: ');
      const data = response.data;
      
      const processedData = data.map(item => {
        const newItem = { ...item };
        let preferenceIndex = 1;
  
        for (const key in newItem) {
          if (Array.isArray(newItem[key])) {
            // Convert array elements into separate columns
            newItem[key].forEach((value, index) => {
              newItem[`preference${preferenceIndex}`] = value;
              preferenceIndex++;
            });
            // Remove the original array attribute
            delete newItem[key];
          }
        }
        return newItem;
      });
  
      const worksheet = XLSX.utils.json_to_sheet(processedData);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "Applicants");
  
      const excelBuffer = XLSX.write(workbook, {
        bookType: "xlsx",
        type: "array",
      });
  
      const blob = new Blob([excelBuffer], { type: "application/octet-stream" });
      saveAs(blob, "Brochure_Institute_Level_ApplicantsList.xlsx");
  
    } catch (error) {
      console.log(error);
    }
  };
  
  const generateExcelBrochureagainstCAP = async () => {
    // console.log("Excel triggered : ",);
    try {
      const response = await axios.get(`${backURL}/getDataBrochureagainstCAP`);
      console.log('Brochure CAP excel received: ');
      const data = response.data;
      
      const processedData = data.map(item => {
        const newItem = { ...item };
        let preferenceIndex = 1;
  
        for (const key in newItem) {
          if (Array.isArray(newItem[key])) {
            // Convert array elements into separate columns
            newItem[key].forEach((value, index) => {
              newItem[`preference${preferenceIndex}`] = value;
              preferenceIndex++;
            });
            // Remove the original array attribute
            delete newItem[key];
          }
        }
        return newItem;
      });
  
      const worksheet = XLSX.utils.json_to_sheet(processedData);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "Applicants");
  
      const excelBuffer = XLSX.write(workbook, {
        bookType: "xlsx",
        type: "array",
      });
  
      const blob = new Blob([excelBuffer], { type: "application/octet-stream" });
      saveAs(blob, "Brochure_against_CAP_Application.xlsx");
  
    } catch (error) {
      console.log(error);
    }
  };

  const FEAdmissionInstituteLevelExcel = async () => {
    // console.log("Excel triggered : ",);
    try {
      const response = await axios.get(`${backURL}/getDataBrochure`);
      console.log('Brochure CAP excel received: ');
      const data = response.data;
      
      const processedData = data.map(item => {
        const newItem = { ...item };
        let preferenceIndex = 1;
  
        for (const key in newItem) {
          if (Array.isArray(newItem[key])) {
            // Convert array elements into separate columns
            newItem[key].forEach((value, index) => {
              newItem[`preference${preferenceIndex}`] = value;
              preferenceIndex++;
            });
            // Remove the original array attribute
            delete newItem[key];
          }
        }
        return newItem;
      });
  
      const worksheet = XLSX.utils.json_to_sheet(processedData);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "Applicants");
  
      const excelBuffer = XLSX.write(workbook, {
        bookType: "xlsx",
        type: "array",
      });
  
      const blob = new Blob([excelBuffer], { type: "application/octet-stream" });
      saveAs(blob, "Admission_Institute_level_Application.xlsx");
  
    } catch (error) {
      console.log(error);
    }
  };
  

  const FEAdmissionMinorityExcel = async () => {
    // console.log("Excel triggered : ",);
    try {
      const response = await axios.get(`${backURL}/getDataBrochure`);
      console.log('Brochure CAP excel received: ');
      const data = response.data;
      
      const processedData = data.map(item => {
        const newItem = { ...item };
        let preferenceIndex = 1;
  
        for (const key in newItem) {
          if (Array.isArray(newItem[key])) {
            // Convert array elements into separate columns
            newItem[key].forEach((value, index) => {
              newItem[`preference${preferenceIndex}`] = value;
              preferenceIndex++;
            });
            // Remove the original array attribute
            delete newItem[key];
          }
        }
        return newItem;
      });
  
      const worksheet = XLSX.utils.json_to_sheet(processedData);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "Applicants");
  
      const excelBuffer = XLSX.write(workbook, {
        bookType: "xlsx",
        type: "array",
      });
  
      const blob = new Blob([excelBuffer], { type: "application/octet-stream" });
      saveAs(blob, "Admission_Minority_Application.xlsx");
  
    } catch (error) {
      console.log(error);
    }
  };

  const FEAdmissionCAPExcel = async () => {
    // console.log("Excel triggered : ",);
    try {
      const response = await axios.get(`${backURL}/getFEAdmisssionCAPExcel`);
      console.log('Brochure CAP excel received: ');
      const data = response.data;
      
      const processedData = data.map(item => {
        const newItem = { ...item };
        let preferenceIndex = 1;
  
        for (const key in newItem) {
          if (Array.isArray(newItem[key])) {
            // Convert array elements into separate columns
            newItem[key].forEach((value, index) => {
              newItem[`preference${preferenceIndex}`] = value;
              preferenceIndex++;
            });
            // Remove the original array attribute
            delete newItem[key];
          }
        }
        return newItem;
      });
  
      const worksheet = XLSX.utils.json_to_sheet(processedData);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "Applicants");
  
      const excelBuffer = XLSX.write(workbook, {
        bookType: "xlsx",
        type: "array",
      });
  
      const blob = new Blob([excelBuffer], { type: "application/octet-stream" });
      saveAs(blob, "Admission_CAP_Application.xlsx");
  
    } catch (error) {
      console.log(error);
    }
  };

  const FEAdmissionagainstCAPvacancyExcel = async () => {
    // console.log("Excel triggered : ",);
    try {
      const response = await axios.get(`${backURL}/getDataBrochureagainstCAP`);
      console.log('Brochure CAP excel received: ');
      const data = response.data;
      
      const processedData = data.map(item => {
        const newItem = { ...item };
        let preferenceIndex = 1;
  
        for (const key in newItem) {
          if (Array.isArray(newItem[key])) {
            // Convert array elements into separate columns
            newItem[key].forEach((value, index) => {
              newItem[`preference${preferenceIndex}`] = value;
              preferenceIndex++;
            });
            // Remove the original array attribute
            delete newItem[key];
          }
        }
        return newItem;
      });
  
      const worksheet = XLSX.utils.json_to_sheet(processedData);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "Applicants");
  
      const excelBuffer = XLSX.write(workbook, {
        bookType: "xlsx",
        type: "array",
      });
  
      const blob = new Blob([excelBuffer], { type: "application/octet-stream" });
      saveAs(blob, "Admission_AgainstCAPvacancy_Application.xlsx");
  
    } catch (error) {
      console.log(error);
    }
    
  };

  const FEAdmissionTFWSlExcel = async () => {
    // console.log("Excel triggered : ",);
    try {
      const response = await axios.get(`${backURL}/getFEAdmissionTFWS`);
      console.log('Brochure CAP excel received: ');
      const data = response.data;
      
      const processedData = data.map(item => {
        const newItem = { ...item };
        let preferenceIndex = 1;
  
        for (const key in newItem) {
          if (Array.isArray(newItem[key])) {
            // Convert array elements into separate columns
            newItem[key].forEach((value, index) => {
              newItem[`preference${preferenceIndex}`] = value;
              preferenceIndex++;
            });
            // Remove the original array attribute
            delete newItem[key];
          }
        }
        return newItem;
      });
  
      const worksheet = XLSX.utils.json_to_sheet(processedData);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "Applicants");
  
      const excelBuffer = XLSX.write(workbook, {
        bookType: "xlsx",
        type: "array",
      });
  
      const blob = new Blob([excelBuffer], { type: "application/octet-stream" });
      saveAs(blob, "Admission_TFWS_Application.xlsx");
  
    } catch (error) {
      console.log(error);
    }
  };

//
  return (
    <>
    {}
    <div className="title">
    <h2>Admission list </h2>
    
  </div>


  <div className="search-container">
    <div className="row search-bar-row">
      <div className="col-1">
        <div className="col-1 search-bar-icon ">
          {" "}
          <b>Search</b>
        </div>
      </div>
      <div className="col-10">
        <div className="row ">
          <div className="row admissionSelectButton">
            <div className="col-6 row1col1 ">
              <div className="row">
                <div className="col-4">Admission Type </div>
                <div className="col-8">
                  <div className="dropdown dropdown-btn |">
                    <div className="dropdown SelectButton">
                      <button
                        className="btn btn-secondary dropdown-toggle typeSelect"
                        type="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        {AdmissionType}
                      </button>
                      <ul className="dropdown-menu">
                       
                        <li
                          className="dropdown-item"
                          onClick={AdmissionTypeFEAdmissionInstitute}
                        >
                          FE Admission Institute level
                        </li>
                        <li
                          className="dropdown-item"
                          onClick={AdmissionTypeFEMinority}
                        >
                          FE Admission Minority
                        </li>
                        <li
                          className="dropdown-item"
                          onClick={AdmissionTypeFECAP}
                        >
                          FE Admission CAP
                        </li>
                        <li
                          className="dropdown-item"
                          onClick={AdmissionTypeFEAgainstCAPVacancy}
                        >
                          FE Admission against CAP Vacancy
                        </li>
                        <li
                          className="dropdown-item"
                          onClick={AdmissionTypeFETFWS}
                        >
                          FE Admission TFWS
                        </li>
                        <li
                          className="dropdown-item"
                          onClick={AdmissionTypeDSECAP}
                        >
                          DSE CAP
                        </li>
                        <li
                          className="dropdown-item"
                          onClick={AdmissionTypeDSEAgainstCAPVacancy}
                        >
                          DSE Against CAP 
                        </li>
                        <li
                          className="dropdown-item"
                          onClick={AdmissionTypeDSEMinority}
                        >
                          DSE Minority 
                        </li>
                        
                        
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-6 row1col1">
              <div className="row">
                <div className="col-4">Admission Status</div>
                <div className="col-8">
                  <div className="dropdown dropdown-btn SelectButton">
                    <div className="dropdown SelectButton">
                      <button
                        className="btn btn-secondary dropdown-toggle typeSelect"
                        type="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        {AdmissionStatus}
                      </button>
                      <ul className="dropdown-menu">
                        <li className="dropdown-item" onClick={setAdmissionStatusAdmitted}>
                          Admitted
                        </li>
                        <li className="dropdown-item" onClick={setAdmissionStatusCancelled}>
                          Cancelled
                        </li>
                        
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* <div className="row ">
          <div className="row admissionSelectButton">
            <div className="col-6 row1col1 admission-type">
              <div className="row">
                <div className="col-4">Documents Status</div>
                <div className="col-8">
                  <div className="dropdown dropdown-btn ">
                    <div className="dropdown SelectButton">
                      <button
                        className="btn btn-secondary dropdown-toggle typeSelect"
                        type="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        {DocStatus}
                      </button>
                      <ul className="dropdown-menu">
                        <li
                          className="dropdown-item"
                          onClick={setDocStatusApproved}
                        >
                          Approved
                        </li>
                        <li
                          className="dropdown-item"
                          onClick={setDocStatusNotApproved}
                        >
                          Not Approved
                        </li>
                        <li
                          className="dropdown-item"
                          onClick={setDocStatusRejected}
                        >
                          Rejected
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-6 row1col1">
              <div className="row">
                <div className="col-4">Transaction Status</div>
                <div className="col-8">
                  <div className="dropdown dropdown-btn ">
                    <div className="dropdown SelectButton">
                      <button
                        className="btn btn-secondary dropdown-toggle typeSelect"
                        type="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        {TransactionStatus}
                      </button>
                      <ul className="dropdown-menu">
                        <li
                          className="dropdown-item"
                          onClick={setTransactionStatusApproved}
                        >
                          Approved
                        </li>
                        <li
                          className="dropdown-item"
                          onClick={setTransactionStatusNotApproved}
                        >
                          Not Approved
                        </li>
                        <li
                          className="dropdown-item"
                          onClick={setTransactionStatusRejected}
                        >
                          Rejected
                        </li>
                        <li
                          className="dropdown-item"
                          onClick={setTransactionStatusNotApplicable}
                        >
                          Not Applicable
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div> */}
      </div>
    </div>
  </div>
  {/* <div className="exam-type-toggle">
  <button
    type="button"
    className={`btn ${examType === 'cet' ? 'btn-primary' : 'btn-secondary'}`}
    onClick={() => setExamType('cet')}
  >
    CET
  </button>
  <button
    type="button"
    className={`btn ${examType === 'jee' ? 'btn-primary' : 'btn-secondary'}`}
    onClick={() => setExamType('jee')}
  >
    JEE
  </button>
</div> */}

  {AdmissionType === "FE Admission Institute level" && AdmissionStatus === "Admitted" && (
    <>
    FE Admission Institute level Cancellation
      <div className="excel-gen">
        <div className="col">
          <button
            type="button"
            onClick={() => {
              FEAdmissionInstituteLevelExcel();
            }}
            className="btn excel-btn"
          >
            Download Excel
          </button>

        </div>
      </div>
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th scope="col"></th>
              <th scope="col">UID</th>
              <th scope="col">Name</th>
              <th scope="col">Admission Type</th>
              <th scope="col">Admission Status</th>
              <th scope="col">Verify</th>   
            </tr>
          </thead>
          <tbody>
            {data2.map((row, index) => {
              if (
                row.documentsApproved === "Approved" &&
                row.transactionproofStatus === "Approved"
              ) {
                return (
                  <tr key={row.id}>
                    <th scope="row">{index + 1}</th>
                    <td>{row.id}</td>
                    <td>{row.fullname}</td>
                    <td>FE Admission Institute level</td>
                    <td>Admitted</td>
                    <td>
                      <button
                        type="button"
                        onClick={() => {
                            handleAdmissionCancel(row.id);
                        }}
                        className="btn btn-danger"
                      >
                        Cancel Admission
                      </button>
                    </td>
                  </tr>
                );
              }
            })}
          </tbody>
        </table>
      </div>
    </>
  )}

{AdmissionType === "FE Admission Institute level" && AdmissionStatus === "Cancelled" && (
    <>
    FE Admission Institute level Cancellation
      <div className="excel-gen">
        <div className="col">
          <button
            type="button"
            onClick={() => {
              FEAdmissionInstituteLevelExcel();
            }}
            className="btn excel-btn"
          >
            Download Excel
          </button>

        </div>
      </div>
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th scope="col"></th>
              <th scope="col">UID</th>
              <th scope="col">Name</th>
              <th scope="col">Admission Type</th>
              <th scope="col">Admission Status</th>
              <th scope="col">Verify</th>   
            </tr>
          </thead>
          <tbody>
            {data2.map((row, index) => {
              if (
                row.documentsApproved === "Cancelled" &&
                row.transactionproofStatus === "Cancelled"
              ) {
                return (
                  <tr key={row.id}>
                    <th scope="row">{index + 1}</th>
                    <td>{row.id}</td>
                    <td>{row.fullname}</td>
                    <td>FE Admission Institute level</td>
                    <td>Cancelled</td>
                    <td>
                      <button
                        type="button"
                        onClick={() => {
                            handleAdmissionRetake(row.id);
                        }}
                        className="btn btn-success"
                      >
                        Cancel Admission
                      </button>
                    </td>
                  </tr>
                );
              }
            })}
          </tbody>
        </table>
      </div>
    </>
  )}

{AdmissionType === "FE Admission Minority" && AdmissionStatus === "Admitted" && (
    <>
    FE Admission Minority Cancellation
      <div className="excel-gen">
        <div className="col">
          <button
            type="button"
            onClick={() => {
              FEAdmissionInstituteLevelExcel();
            }}
            className="btn excel-btn"
          >
            Download Excel
          </button>

        </div>
      </div>
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th scope="col"></th>
              <th scope="col">UID</th>
              <th scope="col">Name</th>
              <th scope="col">Admission Type</th>
              <th scope="col">Admission Status</th>
              <th scope="col">Verify</th>   
            </tr>
          </thead>
          <tbody>
            {data2.map((row, index) => {
              if (
                row.documentsApproved === "Approved" &&
                row.transactionproofStatus === "Approved"
              ) {
                return (
                  <tr key={row.id}>
                    <th scope="row">{index + 1}</th>
                    <td>{row.id}</td>
                    <td>{row.fullname}</td>
                    <td>FE Admission Minority</td>
                    <td>Admitted</td>
                    <td>
                      <button
                        type="button"
                        onClick={() => {
                            handleAdmissionCancel(row.id);
                        }}
                        className="btn btn-danger"
                      >
                        Cancel Admission
                      </button>
                    </td>
                  </tr>
                );
              }
            })}
          </tbody>
        </table>
      </div>
    </>
  )}

{AdmissionType === "FE Admission Minority" && AdmissionStatus === "Cancelled" && (
    <>
    FE Admission Minority Cancellation
      <div className="excel-gen">
        <div className="col">
          <button
            type="button"
            onClick={() => {
              FEAdmissionInstituteLevelExcel();
            }}
            className="btn excel-btn"
          >
            Download Excel
          </button>

        </div>
      </div>
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th scope="col"></th>
              <th scope="col">UID</th>
              <th scope="col">Name</th>
              <th scope="col">Admission Type</th>
              <th scope="col">Admission Status</th>
              <th scope="col">Verify</th>   
            </tr>
          </thead>
          <tbody>
            {data2.map((row, index) => {
              if (
                row.documentsApproved === "Cancelled" &&
                row.transactionproofStatus === "Cancelled"
              ) {
                return (
                  <tr key={row.id}>
                    <th scope="row">{index + 1}</th>
                    <td>{row.id}</td>
                    <td>{row.fullname}</td>
                    <td>FE Admission Minority</td>
                    <td>Cancelled</td>
                    <td>
                      <button
                        type="button"
                        onClick={() => {
                            handleAdmissionRetake(row.id);
                        }}
                        className="btn btn-success"
                      >
                        Cancel Admission
                      </button>
                    </td>
                  </tr>
                );
              }
            })}
          </tbody>
        </table>
      </div>
    </>
  )}


{AdmissionType === "FE Admission CAP" && AdmissionStatus === "Admitted" && (
    <>
    FE Admission CAP cancellation
      <div className="excel-gen">
        <div className="col">
          <button
            type="button"
            onClick={() => {
              FEAdmissionInstituteLevelExcel();
            }}
            className="btn excel-btn"
          >
            Download Excel
          </button>

        </div>
      </div>
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th scope="col"></th>
              <th scope="col">UID</th>
              <th scope="col">Name</th>
              <th scope="col">Admission Type</th>
              <th scope="col">Admission Status</th>
              <th scope="col">Verify</th>   
            </tr>
          </thead>
          <tbody>
            {data2.map((row, index) => {
              if (
                row.documentsApproved === "Approved" &&
                row.transactionproofStatus === "Approved"
              ) {
                return (
                  <tr key={row.id}>
                    <th scope="row">{index + 1}</th>
                    <td>{row.id}</td>
                    <td>{row.fullname}</td>
                    <td>FE Admission CAP</td>
                    <td>Admitted</td>
                    <td>
                      <button
                        type="button"
                        onClick={() => {
                            handleAdmissionCancel(row.id);
                        }}
                        className="btn btn-danger"
                      >
                        Cancel Admission
                      </button>
                    </td>
                  </tr>
                );
              }
            })}
          </tbody>
        </table>
      </div>
    </>
  )}

{AdmissionType === "FE Admission CAP" && AdmissionStatus === "Cancelled" && (
    <>
   FE Admission CAP cancellation
      <div className="excel-gen">
        <div className="col">
          <button
            type="button"
            onClick={() => {
              FEAdmissionInstituteLevelExcel();
            }}
            className="btn excel-btn"
          >
            Download Excel
          </button>

        </div>
      </div>
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th scope="col"></th>
              <th scope="col">UID</th>
              <th scope="col">Name</th>
              <th scope="col">Admission Type</th>
              <th scope="col">Admission Status</th>
              <th scope="col">Verify</th>   
            </tr>
          </thead>
          <tbody>
            {data2.map((row, index) => {
              if (
                row.documentsApproved === "Cancelled" &&
                row.transactionproofStatus === "Cancelled"
              ) {
                return (
                  <tr key={row.id}>
                    <th scope="row">{index + 1}</th>
                    <td>{row.id}</td>
                    <td>{row.fullname}</td>
                    <td>FE Admission CAP</td>
                    <td>Cancelled</td>
                    <td>
                      <button
                        type="button"
                        onClick={() => {
                            handleAdmissionRetake(row.id);
                        }}
                        className="btn btn-success"
                      >
                        Cancel Admission
                      </button>
                    </td>
                  </tr>
                );
              }
            })}
          </tbody>
        </table>
      </div>
    </>
  )}


{AdmissionType === "FE Admission against CAP Vacancy" && AdmissionStatus === "Admitted" && (
    <>
    FE Admission against CAP Vacancy cancellation
      <div className="excel-gen">
        <div className="col">
          <button
            type="button"
            onClick={() => {
              FEAdmissionInstituteLevelExcel();
            }}
            className="btn excel-btn"
          >
            Download Excel
          </button>

        </div>
      </div>
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th scope="col"></th>
              <th scope="col">UID</th>
              <th scope="col">Name</th>
              <th scope="col">Admission Type</th>
              <th scope="col">Admission Status</th>
              <th scope="col">Verify</th>   
            </tr>
          </thead>
          <tbody>
            {data2.map((row, index) => {
              if (
                row.documentsApproved === "Approved" &&
                row.transactionproofStatus === "Approved"
              ) {
                return (
                  <tr key={row.id}>
                    <th scope="row">{index + 1}</th>
                    <td>{row.id}</td>
                    <td>{row.fullname}</td>
                    <td>FE Admission against CAP Vacancy</td>
                    <td>Admitted</td>
                    <td>
                      <button
                        type="button"
                        onClick={() => {
                            handleAdmissionCancel(row.id);
                        }}
                        className="btn btn-danger"
                      >
                        Cancel Admission
                      </button>
                    </td>
                  </tr>
                );
              }
            })}
          </tbody>
        </table>
      </div>
    </>
  )}
  
{AdmissionType === "FE Admission against CAP Vacancy" && AdmissionStatus === "Cancelled" && (
    <>
    FE Admission against CAP Vacancy cancellation
      <div className="excel-gen">
        <div className="col">
          <button
            type="button"
            onClick={() => {
              FEAdmissionInstituteLevelExcel();
            }}
            className="btn excel-btn"
          >
            Download Excel
          </button>

        </div>
      </div>
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th scope="col"></th>
              <th scope="col">UID</th>
              <th scope="col">Name</th>
              <th scope="col">Admission Type</th>
              <th scope="col">Admission Status</th>
              <th scope="col">Verify</th>   
            </tr>
          </thead>
          <tbody>
            {data2.map((row, index) => {
              if (
                row.documentsApproved === "Cancelled" &&
                row.transactionproofStatus === "Cancelled"
              ) {
                return (
                  <tr key={row.id}>
                    <th scope="row">{index + 1}</th>
                    <td>{row.id}</td>
                    <td>{row.fullname}</td>
                    <td>FE Admission against CAP Vacancy</td>
                    <td>Cancelled</td>
                    <td>
                      <button
                        type="button"
                        onClick={() => {
                            handleAdmissionRetake(row.id);
                        }}
                        className="btn btn-success"
                      >
                        Cancel Admission
                      </button>
                    </td>
                  </tr>
                );
              }
            })}
          </tbody>
        </table>
      </div>
    </>
  )}


{AdmissionType === "FE Admission TFWS" && AdmissionStatus === "Admitted" && (
    <>
    FE Admission TFWS cancellation
      <div className="excel-gen">
        <div className="col">
          <button
            type="button"
            onClick={() => {
              FEAdmissionInstituteLevelExcel();
            }}
            className="btn excel-btn"
          >
            Download Excel
          </button>

        </div>
      </div>
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th scope="col"></th>
              <th scope="col">UID</th>
              <th scope="col">Name</th>
              <th scope="col">Admission Type</th>
              <th scope="col">Admission Status</th>
              <th scope="col">Verify</th>   
            </tr>
          </thead>
          <tbody>
            {data2.map((row, index) => {
              if (
                row.documentsApproved === "Approved" &&
                row.transactionproofStatus === "Approved"
              ) {
                return (
                  <tr key={row.id}>
                    <th scope="row">{index + 1}</th>
                    <td>{row.id}</td>
                    <td>{row.fullname}</td>
                    <td>FE Admission TFWS</td>
                    <td>Admitted</td>
                    <td>
                      <button
                        type="button"
                        onClick={() => {
                            handleAdmissionCancel(row.id);
                        }}
                        className="btn btn-danger"
                      >
                        Cancel Admission
                      </button>
                    </td>
                  </tr>
                );
              }
            })}
          </tbody>
        </table>
      </div>
    </>
  )}

{AdmissionType === "FE Admission TFWS" && AdmissionStatus === "Cancelled" && (
    <>
    FE Admission TFWS cancellation
      <div className="excel-gen">
        <div className="col">
          <button
            type="button"
            onClick={() => {
              FEAdmissionInstituteLevelExcel();
            }}
            className="btn excel-btn"
          >
            Download Excel
          </button>

        </div>
      </div>
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th scope="col"></th>
              <th scope="col">UID</th>
              <th scope="col">Name</th>
              <th scope="col">Admission Type</th>
              <th scope="col">Admission Status</th>
              <th scope="col">Verify</th>   
            </tr>
          </thead>
          <tbody>
            {data2.map((row, index) => {
              if (
                row.documentsApproved === "Cancelled" &&
                row.transactionproofStatus === "Cancelled"
              ) {
                return (
                  <tr key={row.id}>
                    <th scope="row">{index + 1}</th>
                    <td>{row.id}</td>
                    <td>{row.fullname}</td>
                    <td>FE Admission TFWS</td>
                    <td>Cancelled</td>
                    <td>
                      <button
                        type="button"
                        onClick={() => {
                            handleAdmissionRetake(row.id);
                        }}
                        className="btn btn-success"
                      >
                        Cancel Admission
                      </button>
                    </td>
                  </tr>
                );
              }
            })}
          </tbody>
        </table>
      </div>
    </>
  )}

   
{AdmissionType === "DSE CAP" && AdmissionStatus === "Admitted" && (
    <>
    DSE CAP cancellation
      <div className="excel-gen">
        <div className="col">
          <button
            type="button"
            onClick={() => {
              FEAdmissionInstituteLevelExcel();
            }}
            className="btn excel-btn"
          >
            Download Excel
          </button>

        </div>
      </div>
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th scope="col"></th>
              <th scope="col">UID</th>
              <th scope="col">Name</th>
              <th scope="col">Admission Type</th>
              <th scope="col">Admission Status</th>
              <th scope="col">Verify</th>   
            </tr>
          </thead>
          <tbody>
            {data2.map((row, index) => {
              if (
                row.documentsApproved === "Approved" &&
                row.transactionproofStatus === "Approved"
              ) {
                return (
                  <tr key={row.id}>
                    <th scope="row">{index + 1}</th>
                    <td>{row.id}</td>
                    <td>{row.fullname}</td>
                    <td>DSE CAP</td>
                    <td>Admitted</td>
                    <td>
                      <button
                        type="button"
                        onClick={() => {
                            handleAdmissionCancel(row.id);
                        }}
                        className="btn btn-danger"
                      >
                        Cancel Admission
                      </button>
                    </td>
                  </tr>
                );
              }
            })}
          </tbody>
        </table>
      </div>
    </>
  )}


{AdmissionType === "DSE CAP" && AdmissionStatus === "Cancelled" && (
    <>
     DSE CAP cancellation
      <div className="excel-gen">
        <div className="col">
          <button
            type="button"
            onClick={() => {
              FEAdmissionInstituteLevelExcel();
            }}
            className="btn excel-btn"
          >
            Download Excel
          </button>

        </div>
      </div>
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th scope="col"></th>
              <th scope="col">UID</th>
              <th scope="col">Name</th>
              <th scope="col">Admission Type</th>
              <th scope="col">Admission Status</th>
              <th scope="col">Verify</th>   
            </tr>
          </thead>
          <tbody>
            {data2.map((row, index) => {
              if (
                row.documentsApproved === "Cancelled" &&
                row.transactionproofStatus === "Cancelled"
              ) {
                return (
                  <tr key={row.id}>
                    <th scope="row">{index + 1}</th>
                    <td>{row.id}</td>
                    <td>{row.fullname}</td>
                    <td>DSE CAP</td>
                    <td>Cancelled</td>
                    <td>
                      <button
                        type="button"
                        onClick={() => {
                            handleAdmissionRetake(row.id);
                        }}
                        className="btn btn-success"
                      >
                        Cancel Admission
                      </button>
                    </td>
                  </tr>
                );
              }
            })}
          </tbody>
        </table>
      </div>
    </>
  )}

{AdmissionType === "DSE Against CAP Vacancy" && AdmissionStatus === "Admitted" && (
    <>
    DSE ACAP Vacancy cancellation
      <div className="excel-gen">
        <div className="col">
          <button
            type="button"
            onClick={() => {
              FEAdmissionInstituteLevelExcel();
            }}
            className="btn excel-btn"
          >
            Download Excel
          </button>

        </div>
      </div>
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th scope="col"></th>
              <th scope="col">UID</th>
              <th scope="col">Name</th>
              <th scope="col">Admission Type</th>
              <th scope="col">Admission Status</th>
              <th scope="col">Verify</th>   
            </tr>
          </thead>
          <tbody>
            {data2.map((row, index) => {
              if (
                row.documentsApproved === "Approved" &&
                row.transactionproofStatus === "Approved"
              ) {
                return (
                  <tr key={row.id}>
                    <th scope="row">{index + 1}</th>
                    <td>{row.id}</td>
                    <td>{row.fullname}</td>
                    <td>DSE Against CAP Vacancy</td>
                    <td>Admitted</td>
                    <td>
                      <button
                        type="button"
                        onClick={() => {
                            handleAdmissionCancel(row.id);
                        }}
                        className="btn btn-danger"
                      >
                        Cancel Admission
                      </button>
                    </td>
                  </tr>
                );
              }
            })}
          </tbody>
        </table>
      </div>
    </>
  )}

{AdmissionType === "DSE Against CAP Vacancy" && AdmissionStatus === "Cancelled" && (
    <>
    DSE ACAP Vacancy cancellation
      <div className="excel-gen">
        <div className="col">
          <button
            type="button"
            onClick={() => {
              FEAdmissionInstituteLevelExcel();
            }}
            className="btn excel-btn"
          >
            Download Excel
          </button>

        </div>
      </div>
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th scope="col"></th>
              <th scope="col">UID</th>
              <th scope="col">Name</th>
              <th scope="col">Admission Type</th>
              <th scope="col">Admission Status</th>
              <th scope="col">Verify</th>   
            </tr>
          </thead>
          <tbody>
            {data2.map((row, index) => {
              if (
                row.documentsApproved === "Cancelled" &&
                row.transactionproofStatus === "Cancelled"
              ) {
                return (
                  <tr key={row.id}>
                    <th scope="row">{index + 1}</th>
                    <td>{row.id}</td>
                    <td>{row.fullname}</td>
                    <td>DSE Against CAP Vacancy</td>
                    <td>Cancelled</td>
                    <td>
                      <button
                        type="button"
                        onClick={() => {
                            handleAdmissionRetake(row.id);
                        }}
                        className="btn btn-success"
                      >
                        Cancel Admission
                      </button>
                    </td>
                  </tr>
                );
              }
            })}
          </tbody>
        </table>
      </div>
    </>
  )}


{AdmissionType === "DSE Minority" && AdmissionStatus === "Admitted" && (
    <>
    DSE minority cancelletion
      <div className="excel-gen">
        <div className="col">
          <button
            type="button"
            onClick={() => {
              FEAdmissionInstituteLevelExcel();
            }}
            className="btn excel-btn"
          >
            Download Excel
          </button>

        </div>
      </div>
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th scope="col"></th>
              <th scope="col">UID</th>
              <th scope="col">Name</th>
              <th scope="col">Admission Type</th>
              <th scope="col">Admission Status</th>
              <th scope="col">Verify</th>   
            </tr>
          </thead>
          <tbody>
            {data2.map((row, index) => {
              if (
                row.documentsApproved === "Approved" &&
                row.transactionproofStatus === "Approved"
              ) {
                return (
                  <tr key={row.id}>
                    <th scope="row">{index + 1}</th>
                    <td>{row.id}</td>
                    <td>{row.fullname}</td>
                    <td>DSE Minority</td>
                    <td>Admitted</td>
                    <td>
                      <button
                        type="button"
                        onClick={() => {
                            handleAdmissionCancel(row.id);
                        }}
                        className="btn btn-danger"
                      >
                        Cancel Admission
                      </button>
                    </td>
                  </tr>
                );
              }
            })}
          </tbody>
        </table>
      </div>
    </>
  )}


{AdmissionType === "DSE Minority" && AdmissionStatus === "Cancelled" && (
    <>
    DSE minority cancelletion
      <div className="excel-gen">
        <div className="col">
          <button
            type="button"
            onClick={() => {
              FEAdmissionInstituteLevelExcel();
            }}
            className="btn excel-btn"
          >
            Download Excel
          </button>

        </div>
      </div>
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th scope="col"></th>
              <th scope="col">UID</th>
              <th scope="col">Name</th>
              <th scope="col">Admission Type</th>
              <th scope="col">Admission Status</th>
              <th scope="col">Verify</th>   
            </tr>
          </thead>
          <tbody>
            {data2.map((row, index) => {
              if (
                row.documentsApproved === "Cancelled" &&
                row.transactionproofStatus === "Cancelled"
              ) {
                return (
                  <tr key={row.id}>
                    <th scope="row">{index + 1}</th>
                    <td>{row.id}</td>
                    <td>{row.fullname}</td>
                    <td>DSE Minority</td>
                    <td>Cancelled</td>
                    <td>
                      <button
                        type="button"
                        onClick={() => {
                            handleAdmissionRetake(row.id);
                        }}
                        className="btn btn-success"
                      >
                        Cancel Admission
                      </button>
                    </td>
                  </tr>
                );
              }
            })}
          </tbody>
        </table>
      </div>
    </>
  )}

{/* 

  {AdmissionType === "FE Admission against CAP Vacancy" && Class === "FE" && (
    <>
    FE Admission Against CAP vacancy
      <div className="excel-gen">
        <div className="col">
          <button
            type="button"
            onClick={() => {
              FEAdmissionagainstCAPvacancyExcel();
            }}
            className="btn excel-btn"
          >
            Download Excel
          </button>

        </div>
      </div>
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th scope="col"></th>
              <th scope="col">UID</th>
              <th scope="col">Name</th>
              <th scope="col">Year</th>
              <th scope="col">Admission Type</th>
              <th scope="col">Document Status</th>
              <th scope="col">Transaction status</th>
              <th scope="col">Verify</th>
            </tr>
          </thead>
          <tbody>
            {data2.map((row, index) => {
              if (
                row.documentsApproved === DocStatus &&
                row.transactionproofStatus === TransactionStatus
              ) {
                return (
                  <tr key={row.id}>
                    <th scope="row">{index + 1}</th>
                    <td>{row.id}</td>
                    <td>{row.fullname}</td>
                    <td>{row.class}</td>
                    <td>Admission</td>
                    <td>{row.documentsApproved}</td>
                    <td>{row.transactionproofStatus}</td>

                    <td>
                      <button
                        type="button"
                        onClick={() => {
                          navigateToDocVerificationFEAdmission(row.id);
                        }}
                        className="btn verify-btn"
                      >
                        Verify
                      </button>
                    </td>
                  </tr>
                );
              }
            })}
          </tbody>
        </table>
      </div>
    </>
  )}
  {AdmissionType === "Admission" &&
    (Class === "SE" || Class === "TE" || Class === "BE") && (
      <>
      Admission SE TE BE
      <div className="excel-gen">
        <div className="col">
          <button
            type="button"
            onClick={() => {
              generateExcel()
            }}
            className="btn excel-btn"
          >
            Download Excel
          </button>
        </div>
      </div>
        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th scope="col"></th>
                <th scope="col">UID</th>
                <th scope="col">Name</th>
                <th scope="col">Year</th>
                <th scope="col">Admission Type</th>
                <th scope="col">Document Status</th>
                <th scope="col">Transaction status</th>
                <th scope="col">Verify</th>
              </tr>
            </thead>
            <tbody>
              {data2.map((row, index) => {
                if (
                  row.documentsApproved === DocStatus &&
                  row.transactionproofStatus === TransactionStatus &&
                  row.class === Class
                ) {
                  return (
                    <tr key={row.id}>
                      <td scope="row">{indexingtable++}</td>
                      <td>{row.id}</td>
                      <td>{row.fullname}</td>
                      <td>{row.class}</td>
                      <td>Admission</td>
                      <td>{row.documentsApproved}</td>
                      <td>{row.transactionproofStatus}</td>

                      <td>
                        <button
                          type="button"
                          onClick={() => {
                            navigateToDocVerificationFEAdmission(row.id);
                          }}
                          className="btn verify-btn"
                        >
                          Verify
                        </button>
                      </td>
                    </tr>
                  );
                }
              })}
            </tbody>
          </table>
        </div>
      </>
    )}
    {AdmissionType === "FE Admission Minority" && (
      <>
      FE Admission Minority
      <div className="excel-gen">
        <div className="col">
          <button
            type="button"
            onClick={() => {
              FEAdmissionMinorityExcel()
            }}
            className="btn excel-btn"
          >
            Download Excel
          </button>
        </div>
      </div>
        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th scope="col"></th>
                <th scope="col">UID</th>
                <th scope="col">Name</th>
                <th scope="col">Year</th>
                <th scope="col">Admission Type</th>
                <th scope="col">Document Status</th>
                <th scope="col">Transaction status</th>
                <th scope="col">Verify</th>
              </tr>
            </thead>
            <tbody>
              {data2.map((row, index) => {
                if (
                  row.documentsApproved === DocStatus &&
                  row.transactionproofStatus === TransactionStatus &&
                  row.class === Class
                ) {
                  return (
                    <tr key={row.id}>
                      <td scope="row">{indexingtable++}</td>
                      <td>{row.id}</td>
                      <td>{row.fullname}</td>
                      <td>{row.class}</td>
                      <td>Admission</td>
                      <td>{row.documentsApproved}</td>
                      <td>{row.transactionproofStatus}</td>

                      <td>
                        <button
                          type="button"
                          onClick={() => {
                            navigateToDocVerificationFEAdmission(row.id);
                          }}
                          className="btn verify-btn"
                        >
                          Verify
                        </button>
                      </td>
                    </tr>
                  );
                }
              })}
            </tbody>
          </table>
        </div>
      </>
    )}
    {AdmissionType === "FE Admission TFWS" && (
      <>
      FE Admission TFWS
      <div className="excel-gen">
        <div className="col">
          <button
            type="button"
            onClick={() => {
              FEAdmissionTFWSlExcel();
            }}
            className="btn excel-btn"
          >
            Download Excel
          </button>
        </div>
      </div>
        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th scope="col"></th>
                <th scope="col">UID</th>
                <th scope="col">Name</th>
                <th scope="col">Year</th>
                <th scope="col">Admission Type</th>
                <th scope="col">Document Status</th>
                <th scope="col">Transaction status</th>
                <th scope="col">Verify</th>
              </tr>
            </thead>
            <tbody>
              {data2.map((row, index) => {
                if (
                  row.documentsApproved === DocStatus &&
                  row.transactionproofStatus === TransactionStatus &&
                  row.class === Class
                ) {
                  return (
                    <tr key={row.id}>
                      <td scope="row">{indexingtable++}</td>
                      <td>{row.id}</td>
                      <td>{row.fullname}</td>
                      <td>{row.class}</td>
                      <td>Admission</td>
                      <td>{row.documentsApproved}</td>
                      <td>{row.transactionproofStatus}</td>

                      <td>
                        <button
                          type="button"
                          onClick={() => {
                            navigateToDocVerificationFEAdmission(row.id);
                          }}
                          className="btn verify-btn"
                        >
                          Verify
                        </button>
                      </td>
                    </tr>
                  );
                }
              })}
            </tbody>
          </table>
        </div>
      </>
    )}
    {AdmissionType === "FE Admission CAP"  && (
      <>
      FE CAP Admission
      <div className="excel-gen">
        <div className="col">
          <button
            type="button"
            onClick={() => {
              FEAdmissionCAPExcel();
            }}
            className="btn excel-btn"
          >
            Download Excel
          </button>
        </div>
      </div>
        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th scope="col"></th>
                <th scope="col">UID</th>
                <th scope="col">Name</th>
                <th scope="col">Year</th>
                <th scope="col">Admission Type</th>
                <th scope="col">Document Status</th>
                <th scope="col">Transaction status</th>
                <th scope="col">Verify</th>
              </tr>
            </thead>
            <tbody>
              {data2.map((row, index) => {
                if (
                  row.documentsApproved === DocStatus &&
                  row.transactionproofStatus === TransactionStatus &&
                  row.class === Class
                ) {
                  return (
                    <tr key={row.id}>
                      <td scope="row">{indexingtable++}</td>
                      <td>{row.id}</td>
                      <td>{row.fullname}</td>
                      <td>{row.class}</td>
                      <td>Admission</td>
                      <td>{row.documentsApproved}</td>
                      <td>{row.transactionproofStatus}</td>

                      <td>
                        <button
                          type="button"
                          onClick={() => {
                            navigateToDocVerificationFEAdmission(row.id);
                          }}
                          className="btn verify-btn"
                        >
                          Verify
                        </button>
                      </td>
                    </tr>
                  );
                }
              })}
            </tbody>
          </table>
        </div>
      </>
    )}

{AdmissionType === "DSE CAP" && Class === "SE" && (
    <>
    DSE CAP 
      <div className="excel-gen">
        <div className="col">
          <button
            type="button"
            onClick={() => {
              FEAdmissionInstituteLevelExcel();
            }}
            className="btn excel-btn"
          >
            Download Excel
          </button>

        </div>
      </div>
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th scope="col"></th>
              <th scope="col">UID</th>
              <th scope="col">Name</th>
              <th scope="col">Year</th>
              <th scope="col">Admission Type</th>
              <th scope="col">Document Status</th>
              <th scope="col">Transaction status</th>
              <th scope="col">Verify</th>
            </tr>
          </thead>
          <tbody>
            {data2.map((row, index) => {
              if (
                row.documentsApproved === DocStatus &&
                row.transactionproofStatus === TransactionStatus
              ) {
                return (
                  <tr key={row.id}>
                    <th scope="row">{index + 1}</th>
                    <td>{row.id}</td>
                    <td>{row.fullname}</td>
                    <td>{row.class}</td>
                    <td>DSE CAP</td>
                    <td>{row.documentsApproved}</td>
                    <td>{row.transactionproofStatus}</td>

                    <td>
                      <button
                        type="button"
                        onClick={() => {
                          navigateToDocVerificationDSEAdmission(row.id);
                        }}
                        className="btn verify-btn"
                      >
                        Verify
                      </button>
                    </td>
                  </tr>
                );
              }
            })}
          </tbody>
        </table>
      </div>
    </>
  )}

{AdmissionType === "DSE Against CAP Vacancy" && Class === "SE" && (
    <>
    DSE Against CAP Vacancy
      <div className="excel-gen">
        <div className="col">
          <button
            type="button"
            onClick={() => {
              FEAdmissionInstituteLevelExcel();
            }}
            className="btn excel-btn"
          >
            Download Excel
          </button>

        </div>
      </div>
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th scope="col"></th>
              <th scope="col">UID</th>
              <th scope="col">Name</th>
              <th scope="col">Year</th>
              <th scope="col">Admission Type</th>
              <th scope="col">Document Status</th>
              <th scope="col">Transaction status</th>
              <th scope="col">Verify</th>
            </tr>
          </thead>
          <tbody>
            {data2.map((row, index) => {
              if (
                row.documentsApproved === DocStatus &&
                row.transactionproofStatus === TransactionStatus
              ) {
                return (
                  <tr key={row.id}>
                    <th scope="row">{index + 1}</th>
                    <td>{row.id}</td>
                    <td>{row.fullname}</td>
                    <td>{row.class}</td>
                    <td>DSE ACAP</td>
                    <td>{row.documentsApproved}</td>
                    <td>{row.transactionproofStatus}</td>

                    <td>
                      <button
                        type="button"
                        onClick={() => {
                          navigateToDocVerificationDSEAdmission(row.id);
                        }}
                        className="btn verify-btn"
                      >
                        Verify
                      </button>
                    </td>
                  </tr>
                );
              }
            })}
          </tbody>
        </table>
      </div>
    </>
  )}

{AdmissionType === "DSE Minority" && Class === "SE" && (
    <>
    DSE Minority
      <div className="excel-gen">
        <div className="col">
          <button
            type="button"
            onClick={() => {
              FEAdmissionInstituteLevelExcel();
            }}
            className="btn excel-btn"
          >
            Download Excel
          </button>

        </div>
      </div>
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th scope="col"></th>
              <th scope="col">UID</th>
              <th scope="col">Name</th>
              <th scope="col">Year</th>
              <th scope="col">Admission Type</th>
              <th scope="col">Document Status</th>
              <th scope="col">Transaction status</th>
              <th scope="col">Verify</th>
            </tr>
          </thead>
          <tbody>
            {data2.map((row, index) => {
              if (
                row.documentsApproved === DocStatus &&
                row.transactionproofStatus === TransactionStatus
              ) {
                return (
                  <tr key={row.id}>
                    <th scope="row">{index + 1}</th>
                    <td>{row.id}</td>
                    <td>{row.fullname}</td>
                    <td>{row.class}</td>
                    <td>DSE Minority</td>
                    <td>{row.documentsApproved}</td>
                    <td>{row.transactionproofStatus}</td>

                    <td>
                      <button
                        type="button"
                        onClick={() => {
                          navigateToDocVerificationDSEAdmission(row.id);
                        }}
                        className="btn verify-btn"
                      >
                        Verify
                      </button>
                    </td>
                  </tr>
                );
              }
            })}
          </tbody>
        </table>
      </div>
    </>
  )}


  {AdmissionType === "Brochure Institute Level" && (
    <>
    Brochure Institute level
    <div className="excel-gen">
        <div className="col">
          <button
            type="button"
            onClick={() => {
              generateExcelBrochureInstituteLevel();
            }}
            className="btn excel-btn"
          >
            Download Excel
          </button>
        </div>
      </div>
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th scope="col"></th>
              <th scope="col">UID</th>
              <th scope="col">Name</th>
              <th scope="col">Application number</th>
              <th scope="col">Admission Type</th>
              <th scope="col">Document Status</th>
              <th scope="col">Transaction status</th>
              <th scope="col">Verify</th>
            </tr>
          </thead>
          <tbody>
            {data2.map((row, index) => {
              if (
                row.documentsApproved === DocStatus &&
                row.transactionproofStatus === TransactionStatus
              ) {
                return (
                  <tr key={row.id}>
                    <th scope="row">{indexingtable++}</th>
                    <td>{row.id}</td>
                    <td>{row.fullname}</td>
                    <td>{row.cet_application_id}</td>
                    <td>Brochure Institute Level</td>
                    <td>{row.documentsApproved}</td>
                    <td>{row.transactionproofStatus}</td>

                    <td>
                      <button
                        type="button"
                        onClick={() => {
                          navigateToDocVerification(row.id);
                        }}
                        className="btn verify-btn"
                      >
                        Verify
                      </button>
                    </td>
                  </tr>
                );
              }
            })}
          </tbody>
        </table>
      </div>
    </>
  )}

{AdmissionType === "Brochure Against CAP" && (
    <>
    Broochure Against CAP
    <div className="excel-gen">
        <div className="col">
          <button
            type="button"
            onClick={() => {
              generateExcelBrochureagainstCAP();
            }}
            className="btn excel-btn"
          >
            Download Excel
          </button>
        </div>
      </div>
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              <th scope="col"></th>
              <th scope="col">UID</th>
              <th scope="col">Name</th>
              <th scope="col">Application number</th>
              <th scope="col">Admission Type</th>
              <th scope="col">Document Status</th>
              <th scope="col">Transaction status</th>
              <th scope="col">Verify</th>
            </tr>
          </thead>
          <tbody>
            {data2.map((row, index) => {
              if (
                row.documentsApproved === DocStatus &&
                row.transactionproofStatus === TransactionStatus
              ) {
                return (
                  <tr key={row.id}>
                    <th scope="row">{indexingtable++}</th>
                    <td>{row.id}</td>
                    <td>{row.fullname}</td>
                    <td>{row.cet_application_id}</td>
                    <td>{row.formType}</td>
                    <td>{row.documentsApproved}</td>
                    <td>{row.transactionproofStatus}</td>

                    <td>
                      <button
                        type="button"
                        onClick={() => {
                          navigateToDocVerification(row.id);
                        }}
                        className="btn verify-btn"
                      >
                        Verify
                      </button>
                    </td>
                  </tr>
                );
              }
            })}
          </tbody>
        </table>
      </div>
    </>
  )} */}

      
    </>
  );
}

export default CancelAdmission;