import { useRef, useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle";
import { useReactToPrint } from "react-to-print";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import "./FeeReceipt.css"; // Assuming you have a CSS file for additional styling
import { useNavigate, useLocation } from "react-router-dom";
import axios from "axios";

function FeeReceiptFE() {
  const currentDate = new Date();
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth() + 1;
  const day = currentDate.getDate();
  const navigate = useNavigate();
  const location = useLocation();
  const receivedState = location.state;
  console.log(receivedState)
  const [loading, setLoading] = useState(true);
  const [refNumber, setRefNumber] = useState('');
  const [formattedDate,setformattedDate] = useState('');
  const [formData, setFormdata] = useState([]);
  
  const [selectedFees, setSelectedFees] = useState({
    tuition_fee: true,
    development_fee: true,
    exam_fee: true,
    misc_fee: true,
    enrollment_fee: true,
    eligibility_fee: true,
    interim_fee: true,
  });
  const uidRecieved = receivedState.uidtoSend;
  const backUrl = process.env.REACT_APP_backUrl;
  const{ admission_type} = receivedState;

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day} ${month} ${year}`;
  };
  const [customDate, setCustomDate] = useState('');
  
  // Function to format date
  useEffect(() => {
    if (customDate) {
     setformattedDate(formatDate(customDate))
    } else {
      setformattedDate(formatDate(new Date()))
    }
  }, [customDate]);

  useEffect(() => {
    console.log(admission_type)
    if(admission_type==="DSE" || admission_type==="DSE ACAP" || admission_type==="DSE MINORITY"){
      if (uidRecieved) {
        console.log("checking dse")
        axios
          .get(`${backUrl}/getFeeDetailsDSE/${uidRecieved}`)
          .then((response) => {
            setFormdata(response.data);
            setLoading(false);
  
            console.log(formData);
            // setRefNumber(formData.transaction_id); // Set loading to false once data is fetched
          })
          .catch((error) => {
            console.error("There was an error fetching the data!", error);
            setLoading(false); // Set loading to false even if there's an error
          });
      }


    }else{

      if (uidRecieved) {
        axios
          .get(`${backUrl}/getFeeDetailsFE/${uidRecieved}`)
          .then((response) => {
            setFormdata(response.data);
            setLoading(false);
  
            console.log(formData);
            // setRefNumber(formData.transaction_id); // Set loading to false once data is fetched
          })
          .catch((error) => {
            console.error("There was an error fetching the data!", error);
            setLoading(false); // Set loading to false even if there's an error
          });
      }
    }
  }, [uidRecieved,admission_type]);


 

  const handleCheckboxChange = (event) => {
    setSelectedFees({
      ...selectedFees,
      [event.target.name]: event.target.checked,
    });
  };

  const getTotalFees = () => {
    return Object.keys(selectedFees).reduce((total, feeKey) => {
      if (selectedFees[feeKey]) {
        return total + (formData[feeKey] || 0);
      }
      return total;
    }, 0);
  };

  const componentRef = useRef();

  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
    documentTitle: "FeeReceipt",
    pageStyle: `
    @page {
      size: auto;
    }
    @media print {
      body {
        -webkit-print-color-adjust: exact;
        font-size: 18px;
        font-weight: bold;
      }
    }
  `,
  });


  

  const sendFeeReceipt = async () => {
    alert("Sending fee receipt...");
    const canvas = await html2canvas(componentRef.current);
    const imgData = canvas.toDataURL("image/png");

    const pdf = new jsPDF();
    const margin = 10;
    const pdfWidth = pdf.internal.pageSize.getWidth() - margin * 2;
    const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
    pdf.addImage(imgData, "PNG", margin, margin, pdfWidth, pdfHeight);
    const pdfBlob = pdf.output("blob");

    const formData = new FormData();
    formData.append("email", receivedState.email);
    formData.append("file", pdfBlob, "FeeReceipt.pdf");

    try {
      const response = await fetch(
      `${process.env.REACT_APP_backUrl}/uploadfeereceipt`,
        {
          method: "POST",
          body: formData,
        }
      );

      if (!response.ok) {
        throw new Error("Network response was not ok");
      }

      const result = await response.json();

      console.log(result);
      alert("Fee receipt sent successfully!");
    } catch (error) {
      console.error("There was an error sending the PDF!", error);
    }
  };

  const updateTransactionID = async ()=>{
    try{
      const response = await axios.put(`${backUrl}/updateTransactionID/${uidRecieved}/${refNumber}`);
      console.log(response);
    }catch(error){
      console.log(error);
    }
    

  }

  const handleDownload = async () => {
    updateTransactionID();
    alert("Downloading fee receipt...");
    const canvas = await html2canvas(componentRef.current);
    const imgData = canvas.toDataURL("image/png");

    const pdf = new jsPDF();
    const margin = 10;
    const pdfWidth = pdf.internal.pageSize.getWidth() - margin * 2;
    const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
    pdf.addImage(imgData, "PNG", margin, margin, pdfWidth, pdfHeight);
    pdf.save("FeeReceipt.pdf");
  };

  return (
    <div>
      <div className="row">
        <div className="col">
          <button
            type="button"
            className="btn backbtn"
            onClick={() => {
              navigate("/ApplicationList");
            }}
          >
            Back
          </button>
          <div className="row rowpay">
            <div className="col colpay">
              <input
                type="checkbox"
                name="tuition_fee"
                checked={selectedFees.tuition_fee}
                onChange={handleCheckboxChange}
              />
              Tuition Fees
            </div>
            <div className="col colpay">
              <input
                type="checkbox"
                name="development_fee"
                checked={selectedFees.development_fee}
                onChange={handleCheckboxChange}
              />
              Development Fees
            </div>
            <div className="col colpay">
              <input
                type="checkbox"
                name="exam_fee"
                checked={selectedFees.exam_fee}
                onChange={handleCheckboxChange}
              />
              Exam Fees
            </div>
            <div className="col colpay">
              <input
                type="checkbox"
                name="misc_fee"
                checked={selectedFees.misc_fee}
                onChange={handleCheckboxChange}
              />
              Miscellaneous Fees
            </div>
            <div className="col colpay">
              <input
                type="checkbox"
                name="enrollment_fee"
                checked={selectedFees.enrollment_fee}
                onChange={handleCheckboxChange}
              />
              Enrollment Fees
            </div>
            <div className="col colpay">
              <input
                type="checkbox"
                name="eligibility_fee"
                checked={selectedFees.eligibility_fee}
                onChange={handleCheckboxChange}
              />
              Eligibility Fees
            </div>
            <div className="col colpay">
              <input
                type="checkbox"
                name="interim_fee"
                checked={selectedFees.interim_fee}
                onChange={handleCheckboxChange}
              />
              Interim Fees
            </div>
          </div>
        </div>
      </div>
      <div className="input-group mb-3 roottt">
        <span className="input-group-text" id="inputGroup-sizing-default">
          Enter DD No./Neft Ref. No.
        </span>
        <input
          type="text"
          className="form-control"
          aria-label="Sizing example input"
          aria-describedby="inputGroup-sizing-default"
          value={refNumber} // Controlled input value
          onChange={(e) => setRefNumber(e.target.value)} // Update state on change
        />
      </div>
      <div className="col colpay dateignore" >
            <input 
              type="date" 
              onChange={(e) => setCustomDate(e.target.value)}
              placeholder="Select Custom Date" 
              style={{ display: 'block' }}
            />
          </div>
      <div ref={componentRef} style={{ padding: "10px", margin: "20px" }}>
        <div className="header">
          <img src="/siesautologo.jpg" alt="SIES Logo" className="logo" />
          <div className="info">
            <h1>The South Indian Education Society</h1>
            <p>SIES Graduate School of Technology</p>
            <p>
              Sri Chandrasekarendra Saraswati Vidyapuram Sector-V, Nerul, Navi
              Mumbai, Maharashtra 400706
            </p>
            <p>Fee Receipt (Student Copy - Original)</p>
          </div>
        </div>
        <div className="body">
          <div className="row rowpay">
            <div className="col colpay">
            Receipt number : <br />
SIES/GST/{admission_type.includes("DSE") ? "DSE" : "FE"}/2024-2025/00{formData.receiptNumber}

            </div>
            <div className="col colpay">
              Student Name : {receivedState.fullName}
            </div>
          </div>
          <div className="row rowpay">
            <div className="col colpay">Receipt Date : {formattedDate}</div>
            <div className="col colpay">Branch : {formData.allotedBranch}</div>
          </div>
          <div className="row rowpay">
            <div className="col colpay">
               DD No./Neft Ref. No. : {refNumber === "" ? formData.transaction_id : refNumber}
            </div>
            <div className="col colpay"></div>
          </div>
          <br />
          <br />
          <br />
          <div className="row rowpay">
            <table className="table">
              <thead>
                <tr>
                  <th className="tablehead" scope="col">
                    Sr No.
                  </th>
                  <th className="tablehead" scope="col">
                    Particulars
                  </th>
                  <th className="tablehead" scope="col">
                    Amount
                  </th>
                </tr>
              </thead>
              <tbody>
                {Object.keys(selectedFees).reduce((acc, feeKey, index) => {
                  if (selectedFees[feeKey]) {
                    acc.push(
                      <tr key={feeKey}>
                        <td>{acc.length + 1}</td>
                        {/* <td>
                          {feeKey
                            .replace("_", " ")
                            .replace(/\b\w/g, (l) => l.toUpperCase())}
                        </td> */}
                        <td>
  {feeKey === "misc_fee"
    ? "Miscellaneous Fees"
    : feeKey
        .replace("_", " ")
        .replace(/\b\w/g, (l) => l.toUpperCase())}
</td>

                        <td>{formData[feeKey]}</td>
                      </tr>
                    );
                  }
                  return acc;
                }, [])}
                <tr>
                  <td colSpan="2" className="tablehead">
                    <strong>Total Fees</strong>
                  </td>
                  <td>
                    <strong>{getTotalFees()}</strong>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <div className="row rowpay">
            <div className="col colpay">
              <div className="signature">
                <br /><br />
                <p>Signature</p>
                <p>(Account by :           )</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* <button className="btn btn-primary" onClick={handlePrint}>
        Print Receipt
      </button> */}
      <button className="btn btn-send2" onClick={sendFeeReceipt}>
        Send Receipt via Email
      </button>
      <button className="btn btn-send2" onClick={handleDownload}>
        Download Receipt as PDF
      </button>
    </div>
  );
}
export default FeeReceiptFE;
