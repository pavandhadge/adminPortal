import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle"; //bootstrap.bundle.min.js / bootstrap.bundle.js


import "./ApplicantsList.css";


import ApplicantsList from "./ApplicantsList";



function Admin() {

      return <ApplicantsList/>
    
}

export default Admin;
