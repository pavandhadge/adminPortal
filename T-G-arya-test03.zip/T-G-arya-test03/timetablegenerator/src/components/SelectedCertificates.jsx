import React,{useEffect,useState} from "react";
import { useLocation, useNavigate } from "react-router-dom";
// import { useState } from "react";
import DownloadPDFButton from "./DownloadPDFButton";
import "./SelectedCertificates.css"; // Import the CSS file for styling

const currentDate = new Date();

// Extract the various components of the date
const year = currentDate.getFullYear();
const month = currentDate.getMonth() + 1; // Months are zero-based (0-11)
const day = currentDate.getDate();
const hours = currentDate.getHours();
const minutes = currentDate.getMinutes();
const seconds = currentDate.getSeconds();
// Format the date as YYYY-MM-DD HH:MM:SS
// const formattedDate = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')} ${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
// const formattedDate = `${day.toString().padStart(2, '0')}-${month.toString().padStart(2, '0')}-${year}`;






const SelectedCertificates = () => {
  const [customDate, setCustomDate] = useState('');
  const [formattedDate,setformattedDate]=useState('');
  const location = useLocation();
  const navigate = useNavigate();
  const { selectedCertificates } = location.state || {
    selectedCertificates: [],
  };
  const [formData, setFormData] = useState({
    rollNo: "222a3065",
    studentName: "Arshad",
    class: "it",
    receiptDate: "20/12/2025",
    tuitionFees: "2000",
    developmentFees: "2000",
    examFees: "2000",
    miscellaneousFees: "2000",
    refno: "07",
    receiptNo: "20/12/2013",
  });
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day}-${month}-${year}`;
  };

  useEffect(() => {
    if (customDate) {
      setformattedDate(formatDate(customDate))
      setFormData((prev) => ({
        ...prev,
        receiptDate: formatDate(customDate),
      }));
    } else {
      setformattedDate(formatDate(new Date()))
      setFormData((prev) => ({
        ...prev,
        receiptDate: formatDate(new Date()), // Reset to current date if no custom date
      }));
    }
  }, [customDate]);

   const backURL = process.env.REACT_APP_backUrl;
   // State to store the email input
   const [email, setEmail] = useState("");
   const [name, setName] = useState("");
   const [branch, setBranch] = useState("");
   const [transactionid, setTransactionID] = useState("");

   const handleEmailChange = (e) => {
     setEmail(e.target.value);
   };
 
   const handleSearchClick = async () => {
     try {
       const response = await fetch(`${backURL}/getdocperinfo/${email}`, {
         method: "GET",
       });

       if (response.ok) {
         const data = await response.json();
         console.log("Response from backend:", data);
         if(data.length === 0){
          alert('Invalid email');
         }
         else{
          setName(data[0].fullname);
          setTransactionID(data[0].transaction_id)
          setBranch(data[0].allotedBranch)
         }
         // Handle the response as needed
       } else {
         console.error("Failed to send email to backend");
         alert('Server error')
       }
     } catch (error) {
       console.error("Error:", error);
     }
   };

  const handleSubmit = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    console.log(formData);
  };

  function getCurrentDate() {
    const today = new Date();
    
    const day = String(today.getDate()).padStart(2, '0'); // Get day and add leading zero if needed
    const month = String(today.getMonth() + 1).padStart(2, '0'); // Get month (0-indexed) and add leading zero
    const year = today.getFullYear(); // Get year
  
    return `${day}/${month}/${year}`; // Return date in DD/MM/YYYY format
  }
  return (
    <div>
      <div className="row searchmail-row">
        <div className="col-9 searchmail-col">
          <div className="input-group mb-3">
            <span className="input-group-text" id="inputGroup-sizing-default">
              Enter email
            </span>
            <input
              type="text"
              className="form-control"
              aria-label="Sizing example input"
              aria-describedby="inputGroup-sizing-default"
              value={email} // Bind the input value to state
              onChange={handleEmailChange} // Update state on input change
            />
          </div>
        </div>
        <div className="col-3 searchmail-col">
        <button type="button" onClick={handleSearchClick} className="btn searchdoc-btn" style={{
            background: " #ff8800",
            border: "none",
            borderRadius: "5px",
            color: "white",
            fontSize: "16px",
            
            width: "200px",
          }}>Search</button>
        </div>
      <div className="col colpay dateignore" >
            <input 
              type="date" 
              onChange={(e) => setCustomDate(e.target.value)}
              placeholder="Select Custom Date" 
              style={{ display: 'block' }}
              />
          </div>
              </div>
      

      <div id="pdf-content">
        <div className="header_selectCertificate" >
          <div className="logodiv_selectCertificate">

          <img src="/siesautologo.jpg" alt="SIES Logo" className="logoselcer" />
          </div>
          <div className="info_selectCertificate">
          <p className="college_selectCertificate" >SIES Graduate School of Technology</p>
            <p>
              Sri Chandrasekarendra Saraswati Vidyapuram Sector-V,</p> 
              <p>Nerul, Navi Mumbai</p>
              <p>Maharashtra 400706
            </p>
          </div>
          <div className="empty_selectCertificate"><div></div></div>
        </div>
            <div className="heading_selectCertificate"><p>RETENTION CERTIFICATE</p></div>
        <div className="body">
          <form onSubmit={handleSubmit} style={{ margin: "20px",fontSize:'28px' }}>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginBottom: "20px", // Reduce margin between rows
              }}
            >
              <span style={{ fontWeight: "bold", width: "25%" }}>Student Name:</span>
              <span style={{ width: "75%", textAlign: "left" }}>
                {name}
              </span>
            </div>
            <div
              style={{ // go ahead 
                display: "flex",
                justifyContent: "space-between",
                marginBottom: "20px", // Reduce margin between rows
              }}
            >
              <span style={{ fontWeight: "bold", width: "25%" }}>Admission date :</span>
              <span style={{ width: "75%", textAlign: "left" }}>
                {formattedDate}
              </span>
            </div>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginBottom: "20px", // Reduce margin between rows
              }}
            >
              <span style={{ fontWeight: "bold", width: "25%" }}>Branch :</span>
              <span style={{ width: "75%", textAlign: "left" }}>
              {branch?.trim()}
              </span>
            </div>

            {selectedCertificates.length > 0 ? (
              <table className="tableforretention">
                <thead>
                  <tr>
                    <th>Sr. No.</th>
                    <th>Submitted Original Documents</th>
                    {/* <th>Original Submitted</th>
                    <th>Xerox Submitted (3 copies)</th> */}
                  </tr>
                </thead>
                <tbody>
                  {selectedCertificates.map((certificate, index) => (
                    <tr key={index}>
                      <td>{index + 1}</td>
                      <td>{certificate}</td>
                      {/* <td></td>
                      <td></td> */}
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <p>No certificates selected.</p>
            )}
            <br /><br /><br />
            <p>Signature</p>
            <p>(Account by       )</p>
          </form>
        </div>
      </div>
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          gap: "20px",
          margin: "50px",
        }}
      >
        <DownloadPDFButton formContent={"pdf-content"} />
        <button
          onClick={() => navigate(-1)}
          style={{
            background: " #ff8800",
            border: "none",
            borderRadius: "5px",
            color: "white",
            fontSize: "16px",
            marginTop: "20px",
            width: "200px",
          }}
        >
          Back
        </button>
      </div>
    </div>
  );
};

export default SelectedCertificates;
